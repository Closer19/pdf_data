package com.example.demo_react.data.dto;

import lombok.*;

@Setter
@Getter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProductDTO {
    private Integer id;
    private String title;
    private String imgsrc;
    private Integer price;
}
