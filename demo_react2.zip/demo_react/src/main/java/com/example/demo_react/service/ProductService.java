package com.example.demo_react.service;

import com.example.demo_react.data.dto.ProductDTO;
import com.example.demo_react.data.entity.Product;
import com.example.demo_react.data.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ProductService {
    private final ProductRepository productRepository;

    public List<ProductDTO> getAllProduct() {
        List<Product> productList = this.productRepository.findAll();
        List<ProductDTO> productDTOList = new ArrayList<>();
        for (Product product : productList) {
            ProductDTO productDTO = ProductDTO.builder()
                    .id(product.getId())
                    .price(product.getPrice())
                    .title(product.getTitle())
                    .imgsrc(product.getImgsrc())
                    .build();

            productDTOList.add(productDTO);
        }

        return productDTOList;
    }

    public ProductDTO saveProduct(ProductDTO productDTO) {
        Product newProduct = Product.builder()
                .title(productDTO.getTitle())
                .price(productDTO.getPrice())
                .imgsrc("http://via.placeholder.com/150x150/00ff00")
                .created(LocalDateTime.now())
                .description("생성")
                .build();
        this.productRepository.save(newProduct);
        ProductDTO retProductDTO=ProductDTO.builder()
                .id(newProduct.getId())
                .title(newProduct.getTitle())
                .price(newProduct.getPrice())
                .imgsrc(newProduct.getImgsrc())
                .build();
        return retProductDTO;
    }

    public ProductDTO updateProduct(ProductDTO productDTO) {
        Optional<Product> productOptional=this.productRepository.findById(productDTO.getId());
            if(productOptional.isPresent()) {
            Product updatedProduct = productOptional.get();
            updatedProduct.setTitle(productDTO.getTitle());
            updatedProduct.setPrice(productDTO.getPrice());
            updatedProduct.setCreated(LocalDateTime.now());
            updatedProduct.setDescription("수정됨");
            this.productRepository.save(updatedProduct);

            ProductDTO updateProductDTO=ProductDTO.builder()
                    .id(updatedProduct.getId())
                    .title(updatedProduct.getTitle())
                    .price(updatedProduct.getPrice())
                    .imgsrc(updatedProduct.getImgsrc())
                    .build();
            return updateProductDTO;
        }
            return null;

    }

    public Integer deleteProduct(Integer id) {
        Optional<Product> productOptional=this.productRepository.findById(id);
        if(productOptional.isPresent()) {
            this.productRepository.deleteById(id);
            return id;
        }
        return -1;
    }



}
