import {createSlice} from "@reduxjs/toolkit";

const initialState={
    pdList:[],
    count:0,
}

const productSlice=createSlice({
    name:"product",
    initialState:initialState,
    reducers:{
        productAdd:(state, action)=>{
            state.pdList.push(action.payload);
            state.count++;
        },
        productUpdate:(state, action)=>{
           state.pdList=state.pdList.map(t=>t.id===action.payload.id? action.payload:t);
        },
        productDelete:(state, action)=>{
            state.pdList=state.pdList.filter(t=>t.id!==action.payload);
            state.count--;
        }

    }
    });

export const {productAdd,productUpdate, productDelete }=productSlice.actions;
export default productSlice.reducer;