import {useDispatch} from "react-redux";
import {useRef} from "react";
import {productAdd} from "./productSlice";
import {useNavigate} from "react-router-dom";
import axios from "axios";

export default function NewProduct(){
    const dispatch=useDispatch();
    const navigate=useNavigate();

    const handleSubmit=async (e)=>{
        try{
            const data={title:e.target.title.value, price:e.target.price.value};
            e.preventDefault();
            const response=await axios.post("http://localhost:8080/product", data,
                {
                    headers:{
                        "Content-Type": "application/json",
                    },
                    timeout:5000,
                }
            );

            dispatch(productAdd(response.data));

        }catch(error){
            if(error.code==="ECONNABORTED"){
                console.error("요청시간 초과");
            }
            console.error(error.message);
        }
        navigate("/");
    }

    return(
        <>
            <h2>New Product</h2>
            <form onSubmit={handleSubmit}>
                <input type="text" name="title"></input>
                <input type="text" name="price"></input>
                <button type="submit">저장</button>
            </form>
        </>
    );
}