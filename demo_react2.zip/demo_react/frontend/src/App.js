
// import './App.css'
import {BrowserRouter, Routes, Route} from "react-router-dom";
import MainLayout from "./MainLayout";
import NewProduct from "./NewProduct";
import EditProduct from "./EditProduct";
import List from "./List";
import DetailProduct from "./DetailProduct";

function App() {
  return (
    <>
        <BrowserRouter>
            <Routes>
                <Route path="/" element={<MainLayout/>}>
                    <Route index element={<List/>}/>
                    <Route path="/detail-product/:id" element={<DetailProduct/>}/>
                    <Route path="/new-product" element={<NewProduct/>}/>
                    <Route path="/edit-product/:id" element={<EditProduct/>}/>
                </Route>

            </Routes>

        </BrowserRouter>
    </>
  )
}

export default App
