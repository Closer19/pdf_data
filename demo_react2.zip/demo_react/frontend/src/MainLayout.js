import {Outlet} from "react-router-dom";
import Navigate from "./Navigate";
import {useSelector, useDispatch} from "react-redux";
import {useEffect} from "react";
import {productAdd} from "./productSlice";
import axios from "axios";
export default function MainLayout(){
    const dispatch=useDispatch();
    const pdList=useSelector(state=>state.product.pdList);

    useEffect(()=>{
        axios.get("http://localhost:8080/product-list", {timeout:5000})
            .then(response=>{
                response.data.map(t=>dispatch(productAdd(t)));
            })
            .catch(error=>{
                if(error.code==="ECONNABORTED"){
                    console.log("요청시간초과");
                } else if(error.response){
                    console.log("서버 에러");
                    console.log(error.response.status);
                    console.log(error.response.data);
                }else if(error.request){
                    console.log("요청 패킷 에러", error.message);
                }else{
                    console.log("에러 발생", error.message);
                }
            });
       }, []);

    return (<>
        <h1>TEST STORE</h1>
        <Navigate></Navigate>
        <Outlet></Outlet>

    </>);
}


