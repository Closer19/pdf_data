import java.util.Scanner;
class InvalidException extends Exception {
    public InvalidException(String s) {
        super(s);
    }
}
public class Main {
    void check(int weight) throws InvalidException {
        if (weight < 100) {
            throw new InvalidException("InvalidException 클래스 호출입니다.");
        }
    }

    public static void main(String args[]) {
        Main obj = new Main();
        try {
            obj.check(60);
        } catch (Exception ex) {
            System.out.println("예외처리입니다.");
            System.out.println(ex);
        }
    }
}