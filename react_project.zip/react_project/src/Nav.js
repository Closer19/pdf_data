export default function Nav(props){
  const il_list=[];
  for(let i=0;i<props.list.length; i++){
    const t=props.list[i];
    const item=<li><a href={"/read/"+(t.id)}>{t.title}</a></li>;
    il_list.push(item);
  }
    return (
    <nav>
      <ol>
      {il_list}
      </ol>
    </nav>
    );
}