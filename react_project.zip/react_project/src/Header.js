function Header(props){
    return(
    <header>
      <h1>환영합니다.!!!{props.title}</h1>
      <h2>{props.desc}</h2>
    </header>
    );
}

export default Header;