import logo from './logo.svg';
import './App.css';
import Header from './Header';
import Nav from './Nav';
import Article from './Article';

function App() { 
  const title="REACT";
  const desc="첫페이지입니다.";
  const li_List=[
    { id:1, title:"html"},
    { id:2, title:"css"},
    { id:3, title:"javascript"}   
  ];
  return (
    <>
    <Header title={title} desc={desc}></Header>
    <Nav list={li_List}></Nav>
    <Article title={title} desc={desc}></Article>     
		</>
  );
}

export default App;
