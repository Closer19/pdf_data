import {useOutletContext} from "react-router-dom";
import apiClient from "../api/axiosInstance";
import {useDispatch} from "react-redux";
import {addUserInfo, clearUserInfo} from "../store";
import {useNavigate} from "react-router-dom";

export default function DetailCondition(){
    const { addr, birthyear}=useOutletContext();
    const addrObj=(<div> 지역: <input type="text" name="addr"></input></div>);
    const birthYearObj=(<div> 출생년도: <input type="text" name="birthyear"></input></div>);
    const dispatch=useDispatch();
    const navigate=useNavigate();

    const handleSubmit=async (e)=>{
        e.preventDefault();
        let paramsData=null;
        let urlpath=null;
        if(addr){
            paramsData={addr:e.target.addr.value};
            urlpath="addr";
        }
        if(birthyear){
            paramsData={...paramsData, birthyear:e.target.birthyear.value};
            urlpath=urlpath? urlpath+"birthyear" : "birthyear";
        }
        try{
            await dispatch(clearUserInfo());
            const response= await apiClient.get("/search-userinfo/"+urlpath,{
                params:paramsData,
            });
            response.data.map(t=>dispatch(addUserInfo(t)));
            navigate("/display-custominfo");

        }catch(error){
            if(error.code==="ECONNABORTED"){
                console.log("응답시간 초과");
            }else if(error.response){
                console.log("서버오류");
                console.log(error.response.status);
                console.log(error.response.body);
                console.log(error);
            }else if(error.request){
                console.log("클라이언트 오류")
                console.log(error.message);
            }else {
                console.log(error);
            }
        }
    }
    return(
        <>
            <p>
            <form onSubmit={handleSubmit}>
                {addr&&addrObj}
                {birthyear&&birthYearObj}
                <button type="submit">검색</button>
            </form>
            </p>
        </>
    );
}