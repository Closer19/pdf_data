import {NavLink, Outlet} from "react-router-dom";

export default function MainLayout(){
    return (
        <>
            <h1>&lt;고객 관리&gt;</h1>
            <NavLink to={"/"}>홈</NavLink>|<NavLink to={"/search"}>검색</NavLink>
            <Outlet/>
        </>
    );
}