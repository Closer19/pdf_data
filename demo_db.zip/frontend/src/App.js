import logo from './logo.svg';
import './App.css';
import {BrowserRouter, Routes, Route} from "react-router-dom";
import MainLayout from "./pages/MainLayout";
import Home from "./pages/Home";
import DetailCondition from "./pages/DetailCondition";
import ConditionSelect from "./pages/ConditionSelect";
import DisplayUserInfo from "./pages/DisplayUserInfo";

function App() {
  return (
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<MainLayout/>}>
            <Route index element={<Home/>}/>
            <Route path="/search" element={<ConditionSelect/>}>
              <Route path="/search/detail-condition" element={<DetailCondition/>}/>
            </Route>
            <Route path="/display-custominfo" element={<DisplayUserInfo/>}></Route>

          </Route>
        </Routes>
      </BrowserRouter>

  );
}

export default App;
