package com.example.demo_db.data.repository;

import com.example.demo_db.data.entity.BuyEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BuyEntityRepository extends JpaRepository<BuyEntity, Integer> {
}
