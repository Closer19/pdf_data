package com.example.demo_db.data.dao;

import com.example.demo_db.data.entity.UserEntity;
import com.example.demo_db.data.repository.UserEntityRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class UserDAO {
    private final UserEntityRepository userEntityRepository;

    public List<UserEntity> searchUserInfo(String addr) {
        return this.userEntityRepository.searchUserInfo(addr);
    }
    public List<UserEntity> searchUserInfo(Integer birthYear) {
        return this.userEntityRepository.searchUserInfo(birthYear);
    }
    public List<UserEntity> searchUserInfo(String addr, Integer birthYear) {
        return this.userEntityRepository.searchUserInfo(addr, birthYear);
    }

}
