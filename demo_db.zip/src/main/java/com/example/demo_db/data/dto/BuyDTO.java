package com.example.demo_db.data.dto;

public class BuyDTO {
}
