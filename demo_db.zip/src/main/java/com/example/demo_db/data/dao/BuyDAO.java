package com.example.demo_db.data.dao;

import com.example.demo_db.data.dto.UserDTO;
import com.example.demo_db.data.repository.UserEntityRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class BuyDAO {

}
