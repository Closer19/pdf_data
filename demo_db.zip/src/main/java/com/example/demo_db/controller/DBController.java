package com.example.demo_db.controller;

import com.example.demo_db.data.entity.BuyEntity;
import com.example.demo_db.data.entity.UserEntity;
import com.example.demo_db.data.repository.BuyEntityRepository;
import com.example.demo_db.data.repository.UserEntityRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequiredArgsConstructor
public class DBController {

}
