import { configureStore, createSlice } from '@reduxjs/toolkit';

// 초기 포스트 리스트
const initialPosts = {
  postList:[],
}

// Redux slice 생성
const postsSlice = createSlice({
  name: 'posts',
  initialState: initialPosts,
  reducers: {
    addPost: (state, action) => {
      state.postList.push(action.payload);
    },
    updatePost: (state, action) => {
      const { id, title, content } = action.payload;
      const existingPost = state.postList.find((post) => post.id === id);
      if (existingPost) {
        existingPost.title = title;
        existingPost.content = content;
      }
    },
    deletePost: (state, action) => {
      state.postList=state.postList.filter((post) => post.id !== action.payload);
    },
  },
});

// Action과 reducer export
export const { addPost, updatePost, deletePost } = postsSlice.actions;
export default configureStore({
  reducer: {
    posts: postsSlice.reducer,
  },
});
