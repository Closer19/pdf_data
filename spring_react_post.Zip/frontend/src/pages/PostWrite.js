import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { addPost } from '../store';
import { useNavigate } from 'react-router-dom';
import apiClient from "../api/axioInstance";

function PostWrite() {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleSubmit = async () => {
    const newPost = {
      title,
      content,
    };
    const response=await apiClient.post("/post",newPost);
    dispatch(addPost(response.data));
    navigate('/posts');
  };

  return (
    <div>
      <h1>Write a New Post</h1>
      <input
        type="text"
        placeholder="Title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
      /><br/><br/>
      <textarea
        placeholder="Content"
        value={content}
        onChange={(e) => setContent(e.target.value)}
      /><br/><br/>
      <button onClick={handleSubmit}>Save</button>
    </div>
  );
}

export default PostWrite;
