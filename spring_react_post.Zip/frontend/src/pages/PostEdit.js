import { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { updatePost } from '../store';
import { useParams, useNavigate } from 'react-router-dom';
import apiClient from "../api/axioInstance";

function PostEdit() {
  const { id } = useParams();
  const post = useSelector((state) => state.posts.postList.find((post) => post.id === parseInt(id)));
  const [title, setTitle] = useState(post?.title || '');
  const [content, setContent] = useState(post?.content || '');
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleSubmit = async () => {
      const response=await apiClient.put("/post",{ id: post.id, title, content} )
      dispatch(updatePost(response.data));
      navigate('/posts');
  };

  if (!post) return <p>Post not found</p>;

  return (
    <div>
      <h1>Edit Post</h1>
      <input
        type="text"
        placeholder="Title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
      /><br/><br/>
      <textarea
        placeholder="Content"
        value={content}
        onChange={(e) => setContent(e.target.value)}
      /><br/><br/>
      <button onClick={handleSubmit}>Save</button>
    </div>
  );
}

export default PostEdit;
