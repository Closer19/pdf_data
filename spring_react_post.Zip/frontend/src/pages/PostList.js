import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Link } from 'react-router-dom';
import { deletePost } from '../store';
import apiClient from "../api/axioInstance";

function PostList() {
  const posts = useSelector((state) => state.posts.postList);
  const dispatch = useDispatch();

  const handleDelete = async (id) => {
      try{
          const response=await apiClient.delete("/post/"+id);
          dispatch(deletePost(response.data));
      }catch(error){
          if(error.code==="ECONNABORTED"){
              console.log("요청 시간 초과");
          }else if(error.response) {
              console.log(error.response.status);
              console.log("응답오류데이터:");
              console.log(error.response.body)
          }else if(error.request){
              console.log("요청오류:");
              console.log(error.message);
          }else{
              console.log(error.message);
          }
      }
  };

  if(!posts){
      return null;
  }

  return (
    <div>
      <h1>Post List</h1>
      <ul>
        {posts.map((post) => (
          <li key={post.id}>
            <Link to={`/posts/${post.id}`}>{post.title}</Link>&nbsp;&nbsp;
            <button onClick={() => handleDelete(post.id)}>Delete</button>&nbsp;&nbsp;
            <Link to={`/edit/${post.id}`}>Edit</Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default PostList;
