import React from 'react';

function About() {
  return <h1>여기는 React 게시판입니다.</h1>;
}

export default About;