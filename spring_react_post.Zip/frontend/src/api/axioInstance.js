import axios    from "axios";

const apiClient=axios.create({
    baseURL:"http://localhost:8080",
    timeout:3000,
    headers:{
        "Content-type":"application/json",
    }
});

apiClient.interceptors.request.use((config)=>{
    config.headers["Custom-header"]="Hello";
    console.log("Request headers:", config.headers);
    return config;
}, (error)=>{
    return Promise.reject(error);
});

export default apiClient;