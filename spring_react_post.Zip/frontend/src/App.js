
import './App.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Provider } from 'react-redux';
import store from './store';
import Home from './pages/Home';
import PostList from './pages/PostList';
import PostDetail from './pages/PostDetail';
import PostWrite from './pages/PostWrite';
import PostEdit from './pages/PostEdit';
import About from './pages/About';
import {useEffect} from "react";
import apiClient from "./api/axioInstance";
import {useDispatch, useSelector} from "react-redux";
import {addPost} from "./store";

function App() {
    const dispatch=useDispatch();

    useEffect(() => {
        const fetchData=async ()=>{
            try{
                const response=await apiClient.get("/post-list");
                response.data.map(t=>dispatch(addPost(t)));
            }catch(error){
                if(error.code==="ECONNABORTED"){
                    console.log("요청 시간 초과");
                }else if(error.response) {
                    console.log(error.response.status);
                    console.log("응답오류데이터:");
                    console.log(error.response.body)
                }else if(error.request){
                    console.log("요청오류:");
                    console.log(error.message);
                }else{
                    console.log(error.message);
                }
            };
        };
        fetchData();
    }, []);
  return (
    <BrowserRouter>
    <Routes>
          <Route path="/" element={<Home />}>
            <Route index element={<About />}/>
            <Route path="/posts" element={<PostList />} />
            <Route path="/posts/:id" element={<PostDetail />} />
            <Route path="/write" element={<PostWrite />} />
            <Route path="/edit/:id" element={<PostEdit />} />                      
          </Route>        
        </Routes>    
    </BrowserRouter>
    
  );
}

export default App;
