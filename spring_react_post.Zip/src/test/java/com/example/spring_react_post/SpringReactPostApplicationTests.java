package com.example.spring_react_post;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringReactPostApplicationTests {

    @Test
    void contextLoads() {
    }

}
