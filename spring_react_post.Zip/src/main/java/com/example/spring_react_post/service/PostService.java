package com.example.spring_react_post.service;

import com.example.spring_react_post.data.dao.PostDAO;
import com.example.spring_react_post.data.dto.PostDTO;
import com.example.spring_react_post.data.entity.PostEntity;
import com.example.spring_react_post.data.repository.PostRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class PostService {
    private final PostDAO postDAO;

    public List<PostDTO> getAllPosts() {
        List<PostEntity> postEntities = postDAO.getAllPosts();
        List<PostDTO> postDTOS = new ArrayList<>();
        for (PostEntity postEntity : postEntities) {
            PostDTO postDTO = PostDTO.builder()
                    .id(postEntity.getId())
                    .title(postEntity.getTitle())
                    .content(postEntity.getContent())
                    .build();
            postDTOS.add(postDTO);
        }
        return postDTOS;
    }

    public PostDTO getPost(Long id) {
        PostEntity postEntity=this.postDAO.getPostById(id);
        PostDTO postDTO=PostDTO.builder()
                .id(postEntity.getId())
                .title(postEntity.getTitle())
                .content(postEntity.getContent())
                .build();
        return postDTO;
    }

    public PostDTO addPost(PostDTO postDTO) {
        PostEntity postEntity=this.postDAO.addPost(postDTO.getTitle(), postDTO.getContent());
        PostDTO savePostDTO=PostDTO.builder()
                .id(postEntity.getId())
                .title(postEntity.getTitle())
                .content(postEntity.getContent())
                .build();
        return savePostDTO;
    }

    public PostDTO updatePost(PostDTO postDTO) {
        PostEntity postEntity=this.postDAO.updatePost(postDTO.getId(), postDTO.getTitle(), postDTO.getContent());
        PostDTO updatePostDTO=PostDTO.builder()
                .id(postEntity.getId())
                .title(postEntity.getTitle())
                .content(postEntity.getContent())
                .build();
        return updatePostDTO;
    }

    public Long deletePost(Long id) {
        Long deleteId=this.postDAO.deletePost(id);
        return deleteId;
    }
}