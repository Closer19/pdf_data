package com.example.spring_react_post;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringReactPostApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringReactPostApplication.class, args);
    }

}
