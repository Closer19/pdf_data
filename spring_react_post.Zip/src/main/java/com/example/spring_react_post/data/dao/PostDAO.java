package com.example.spring_react_post.data.dao;

import com.example.spring_react_post.data.entity.PostEntity;
import com.example.spring_react_post.data.repository.PostRepository;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class PostDAO {
    private final PostRepository postRepository;

    public PostEntity addPost(String title, String conent){
        PostEntity postEntity = PostEntity.builder()
                .title(title)
                .content(conent)
                .createdAt(LocalDateTime.now())
                .build();

        return this.postRepository.save(postEntity);
    }

    public List<PostEntity> getAllPosts(){
        return this.postRepository.findAll();
    }

    public PostEntity getPostById(Long id){
        if(!this.postRepository.existsById(id)){
            throw new EntityNotFoundException("없는 아이디입니다 : ID:"+id);
        }
        return this.postRepository.findById(id).get();
    }

    public PostEntity updatePost(Long id, String title, String conent){
        if(!this.postRepository.existsById(id)){
            throw new EntityNotFoundException("없는 아이디입니다 : ID:"+id);
        }
        PostEntity postEntity = this.postRepository.findById(id).get();
        postEntity.setTitle(title);
        postEntity.setContent(conent);
        return this.postRepository.save(postEntity);
    }

    public Long deletePost(Long id){
        if(!this.postRepository.existsById(id)){
            throw new EntityNotFoundException("없는 아이디입니다 : ID:"+id);
        }
        this.postRepository.deleteById(id);
        return id;
    }
}
