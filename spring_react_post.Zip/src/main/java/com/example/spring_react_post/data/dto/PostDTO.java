package com.example.spring_react_post.data.dto;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PostDTO {
    private Long id;
    @Size(min = 1, max = 20, message = "제목을 1~20사이의 길이이여야 합니다.")
    private String title;
    @NotEmpty(message = "내용을 생략할 수 없습니다.")
    private String content;
}
