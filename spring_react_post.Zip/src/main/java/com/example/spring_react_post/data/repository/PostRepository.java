package com.example.spring_react_post.data.repository;

import com.example.spring_react_post.data.entity.PostEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PostRepository extends JpaRepository<PostEntity, Long> {
}
