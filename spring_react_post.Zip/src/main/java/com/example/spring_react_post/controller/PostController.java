package com.example.spring_react_post.controller;

import com.example.spring_react_post.data.dto.PostDTO;
import com.example.spring_react_post.service.PostService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class PostController {

    private final PostService postService;

    @GetMapping(value="/post-list")
    public ResponseEntity<List<PostDTO>> getAllPosts(){
        List<PostDTO> postDTOList = postService.getAllPosts();
        return ResponseEntity.status(HttpStatus.OK).body(postDTOList);
    }

    @PostMapping(value="/post")
    public ResponseEntity<PostDTO> addPost(@Valid @RequestBody PostDTO postDTO){
        PostDTO postDTOSaved = this.postService.addPost(postDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(postDTOSaved);
    }

    @PutMapping(value="/post")
    public ResponseEntity<PostDTO> updatePost(@Valid @RequestBody PostDTO postDTO){
        PostDTO postDTOupdate = this.postService.updatePost(postDTO);
        return ResponseEntity.status(HttpStatus.OK).body(postDTOupdate);
    }

    @DeleteMapping(value="/post/{id}")
    public ResponseEntity<Long> deletePost(@PathVariable("id") Long id){
        this.postService.deletePost(id);
        return ResponseEntity.status(HttpStatus.OK).body(id);
    }
}
