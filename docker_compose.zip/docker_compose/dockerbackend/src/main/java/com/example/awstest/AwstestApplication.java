package com.example.awstest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AwstestApplication {

    public static void main(String[] args) {
        SpringApplication.run(AwstestApplication.class, args);
    }

}
