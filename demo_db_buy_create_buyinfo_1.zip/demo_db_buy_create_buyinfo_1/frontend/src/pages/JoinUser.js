import apiClient from "../api/axiosInstance";
import errorDisplay from "../util/errorDisplay";
import {useState} from "react";
import {HttpStatusCode} from "axios";
import {useRef} from "react";

export default function JoinUser(){
    return(
        <>
        </>
    );
}