export default function DisplayCustomerInfo(){
    return (
        <>
        </>
    );
}