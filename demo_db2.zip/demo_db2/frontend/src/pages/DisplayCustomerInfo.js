import {useSelector} from "react-redux";

export default function DisplayCustomerInfo(){
    const userInfoList=useSelector(state=>state.userInfo.userInfoList);
    const list=userInfoList.map(t=>(
        <div key={t.userid}>
            <hr/>
            <p>고객 아이디 : {t.userid}</p>
            <p>고객 이름 : {t.username}</p>
            <p>고객 전화번호 : {t.mobile}</p>
            <p>고객 출생년도 : {t.birthyear}</p>
            <p>고객 신장 : {t.height}</p>
            <p>고객 거주지역 : {t.addr}</p>
            <p>고객 가입일자 : {t.joindate}</p>
            <hr/>
        </div>
    ));
    return (
        <>
            {list}
        </>
    );
}