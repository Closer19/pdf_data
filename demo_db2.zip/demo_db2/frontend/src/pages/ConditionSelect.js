import {Outlet} from "react-router-dom";
import {useState} from "react";
import {useRef} from "react";
import {useNavigate} from "react-router-dom";

export default function ConditionSelect(){
    const [context, setContext]=useState(null);
    const flag=useRef(false);
    const navigate=useNavigate();
    const handleSubmit=(e)=>{
        e.preventDefault();
        flag.current=false;
        let newContext=null;
        if(e.target.addr.checked){
            newContext={addr:"addr"};
            flag.current=true;
        }
        if(e.target.birthyear.checked){
            newContext={...newContext, birthyear:"birthyear"};
            flag.current=true;
        }
        setContext(newContext);
        // navigate("/search/detail-condition");
    }
    return (
        <>
            <form onSubmit={handleSubmit}>
                <label htmlFor="addr">지역 : </label>
                <input type="checkbox" id="addr" name="addr"/>
                <label htmlFor="birthyear">출생년도 : </label>
                <input type="checkbox" id="birthyear" name="birthyear"/>
                <button type="submit">조건선택</button>
            </form>
            {flag.current && <Outlet context={context}/>}
        </>
    );
}