import {useOutletContext} from "react-router-dom";
import errorDisplay from "../util/errorDisplay";
import apiClient from "../api/axiosInstance";
import {useDispatch} from "react-redux";
import {useNavigate} from "react-router-dom";
import {addUserInfo} from "../store";
import {clearUserInfo} from "../store";

export default function DetailCondition(){
    const { addr, birthyear}=useOutletContext();
    const addrObj=(<div>지역 : <input type="text" name="addr"/></div>);
    const birthyearObj=(<div>출생년도 : <input type="text" name="birthyear"/> </div>);
    const dispatch=useDispatch();
    const navigate=useNavigate();

    const handSubmit=async (e)=>{
        e.preventDefault();
        let paramData=null;

        if(addr){
            paramData={addr:e.target.addr.value};
        }
        if(birthyear){
            paramData={...paramData, birthyear:e.target.birthyear.value}
        }
        try{
            await dispatch(clearUserInfo());
            const response=await apiClient.get("/search-userinfo",{
                params:paramData,
            });

           response.data.map(t=>dispatch(addUserInfo(t)));
           navigate("/display-customerinfo");

        }catch(error){
            errorDisplay(error);
        }
    }

    return (
        <>
            <hr/>
            <form onSubmit={handSubmit}>
                {addr && addrObj}
                {birthyear && birthyearObj}
                <button type="submit">검색</button>
            </form>
            <hr/>

        </>
    );
}