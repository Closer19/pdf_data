import {useOutletContext} from "react-router-dom";

export default function DetailCondition(){
    const { addr, birthyear}=useOutletContext();
    const addrObj=(<div>지역 : <input type="text" name="addr"/></div>);
    const birthyearObj=(<div>출생년도 : <input type="text" name="birthyear"/> </div>);
    return (
        <>

        </>
    );
}