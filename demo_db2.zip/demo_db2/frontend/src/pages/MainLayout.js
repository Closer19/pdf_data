import {Link, Outlet} from "react-router-dom";

export default function MainLayout(){
    return (
        <>
            <h1>&lt;고객관리&gt;</h1>
            <Link to={"/"}>홈</Link> |
            <Link to={"/search"}>검색</Link>
            <Outlet></Outlet>
        </>
    );
}