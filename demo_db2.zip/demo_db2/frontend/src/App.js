import logo from './logo.svg';
import './App.css';
import {BrowserRouter, Routes, Route, Router} from "react-router-dom";
import MainLayout from "./pages/MainLayout";
import Home from "./pages/Home";
import ConditionSelect from "./pages/ConditionSelect";
import DetailCondition from "./pages/DetailCondition";
import DisplayCustomerInfo from "./pages/DisplayCustomerInfo";

function App() {
  return (
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<MainLayout/>}>
            <Route index element={<Home/>}></Route>
            <Route path="/search" element={<ConditionSelect/>}>
              <Route index element={<DetailCondition/>}></Route>
            </Route>
            <Route path="/display-customerinfo" element={<DisplayCustomerInfo/>}></Route>
          </Route>
        </Routes>
      </BrowserRouter>

  );
}

export default App;
