package com.example.demo_db2.data.dao;

import com.example.demo_db2.data.entity.UserEntity;
import com.example.demo_db2.data.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class UserDAO {
    private final UserRepository userRepository;

    public List<UserEntity> searchUserInfo(String addr){
        return this.userRepository.searchUserInfo(addr);
    }

    public List<UserEntity> searchUserInfo(Integer birthyear){
        return this.userRepository.searchUserInfo(birthyear);
    }

    public List<UserEntity> searchUserInfo(String addr, Integer birthyear){
        return this.userRepository.searchUserInfo(addr, birthyear);
    }
}
