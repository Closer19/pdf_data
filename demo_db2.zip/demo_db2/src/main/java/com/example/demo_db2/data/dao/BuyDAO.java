package com.example.demo_db2.data.dao;

public class BuyDAO {
}
