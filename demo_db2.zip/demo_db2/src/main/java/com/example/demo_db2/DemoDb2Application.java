package com.example.demo_db2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoDb2Application {

    public static void main(String[] args) {
        SpringApplication.run(DemoDb2Application.class, args);
    }

}
