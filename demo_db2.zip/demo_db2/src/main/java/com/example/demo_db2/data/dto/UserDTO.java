package com.example.demo_db2.data.dto;

import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UserDTO {
    private String userid;
    private String username;
    private Integer birthyear;
    private String addr;
    private String mobile;
    private Short height;
    private LocalDate joindate;
}
