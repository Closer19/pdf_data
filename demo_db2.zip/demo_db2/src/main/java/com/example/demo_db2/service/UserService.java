package com.example.demo_db2.service;

import com.example.demo_db2.data.dao.UserDAO;
import com.example.demo_db2.data.dto.UserDTO;
import com.example.demo_db2.data.entity.UserEntity;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class UserService {
    private final UserDAO userDAO;

    public List<UserDTO> searchUserInfo(String addr){
        List<UserEntity> userEntityList = userDAO.searchUserInfo(addr);
        List<UserDTO> userDTOList = new ArrayList<>();
        for (UserEntity userEntity : userEntityList) {
            UserDTO userDTO = UserDTO.builder()
                    .userid(userEntity.getUserid())
                    .username(userEntity.getUsername())
                    .addr(userEntity.getAddr())
                    .birthyear(userEntity.getBirthyear())
                    .height(userEntity.getHeight())
                    .mobile(userEntity.getMobile1()+userEntity.getMobile2())
                    .joindate(userEntity.getJoindate())
                    .build();
            userDTOList.add(userDTO);
        }
        return userDTOList;
    }

    public List<UserDTO> searchUserInfo(Integer birthyear){
        List<UserEntity> userEntityList = userDAO.searchUserInfo(birthyear);
        List<UserDTO> userDTOList = new ArrayList<>();
        for (UserEntity userEntity : userEntityList) {
            UserDTO userDTO = UserDTO.builder()
                    .userid(userEntity.getUserid())
                    .username(userEntity.getUsername())
                    .addr(userEntity.getAddr())
                    .birthyear(userEntity.getBirthyear())
                    .height(userEntity.getHeight())
                    .mobile(userEntity.getMobile1()+userEntity.getMobile2())
                    .joindate(userEntity.getJoindate())
                    .build();
            userDTOList.add(userDTO);
        }
        return userDTOList;
    }

    public List<UserDTO> searchUserInfo(String addr,Integer birthyear){
        List<UserEntity> userEntityList = userDAO.searchUserInfo(addr, birthyear);
        List<UserDTO> userDTOList = new ArrayList<>();
        for (UserEntity userEntity : userEntityList) {
            UserDTO userDTO = UserDTO.builder()
                    .userid(userEntity.getUserid())
                    .username(userEntity.getUsername())
                    .addr(userEntity.getAddr())
                    .birthyear(userEntity.getBirthyear())
                    .height(userEntity.getHeight())
                    .mobile(userEntity.getMobile1()+userEntity.getMobile2())
                    .joindate(userEntity.getJoindate())
                    .build();
            userDTOList.add(userDTO);
        }
        return userDTOList;
    }
}
