package com.example.demo_db2.data.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.time.LocalDate;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@Entity
@Table(name = "usertbl")
public class UserEntity {
    @Id
    @Size(max = 8)
    @Column(name = "userid", nullable = false, length = 8)
    private String userid;

    @Size(max = 10)
    @NotNull
    @Column(name = "username", nullable = false, length = 10)
    private String username;

    @NotNull
    @Column(name = "birthyear", nullable = false)
    private Integer birthyear;

    @Size(max = 2)
    @NotNull
    @Column(name = "addr", nullable = false, length = 2)
    private String addr;

    @Size(max = 3)
    @Column(name = "mobile1", length = 3)
    private String mobile1;

    @Size(max = 8)
    @Column(name = "mobile2", length = 8)
    private String mobile2;

    @NotNull
    @Column(name = "height", nullable = false)
    private Short height;

    @NotNull
    @Column(name = "joindate", nullable = false)
    private LocalDate joindate;

}