package com.example.demo_db2.controller;

import com.example.demo_db2.data.dto.UserDTO;
import com.example.demo_db2.data.repository.UserRepository;
import com.example.demo_db2.service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class UserControlloer {
    private final UserService userService;

    @GetMapping(value = "/search-userinfo/addr")
    public ResponseEntity<List<UserDTO>> searchUserInfo(@RequestParam String addr) {
        List<UserDTO> userDTOList = userService.searchUserInfo(addr);
        return ResponseEntity.status(HttpStatus.OK).body(userDTOList);
    }
    @GetMapping(value = "/search-userinfo/birthyear")
    public ResponseEntity<List<UserDTO>> searchUserInfo(@RequestParam Integer bithyear) {
        List<UserDTO> userDTOList = userService.searchUserInfo(bithyear);
        return ResponseEntity.status(HttpStatus.OK).body(userDTOList);
    }

    @GetMapping(value = "/search-userinfo/addr-birthyear")
    public ResponseEntity<List<UserDTO>> searchUserInfo(@RequestParam String addr,
                                 @RequestParam Integer bithyear) {
        List<UserDTO> userDTOList = userService.searchUserInfo(addr, bithyear);
        return ResponseEntity.status(HttpStatus.OK).body(userDTOList);
    }
}
