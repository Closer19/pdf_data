package com.example.demo_db2.data.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "buytbl")
public class BuyEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "num", nullable = false)
    private Integer num;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "userid", nullable = false)
    private UserEntity user;

    @Size(max = 10)
    @NotNull
    @Column(name = "prodname", nullable = false, length = 10)
    private String prodname;

    @Size(max = 4)
    @Column(name = "groupname", length = 4)
    private String groupname;

    @NotNull
    @Column(name = "price", nullable = false)
    private Integer price;

    @NotNull
    @Column(name = "amount", nullable = false)
    private Short amount;

}