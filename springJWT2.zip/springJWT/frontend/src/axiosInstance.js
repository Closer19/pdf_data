import axios, {responseEncoding} from "axios";
import store from "./store";

const apiClient=axios.create({
    baseURL:"http://localhost:8080",
    headers:{
        "Content-Type":"application/json",
    },
});

apiClient.interceptors.request.use((config)=>{
    if(config.data instanceof URLSearchParams){
        config.headers["Content-Type"]="application/x-www-form-urlencoded";
    }
    const jwtToken=store.getState().userInfo.jwtToken;
    config.headers["authorization"]=jwtToken;

},(error)=>{
    return Promise.reject(error);
});

apiClient.interceptors.response.use((response)=>reponse,
    async (error)=>{
    const originalRequest=error.config;
    if(error.response && error.response.status===401 && !originalRequest._retry)
        originalRequest._retry=true;
        try{

        }catch{

        }


    });

