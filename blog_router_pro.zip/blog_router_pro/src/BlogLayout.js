import { NavLink, Outlet, useNavigate} from "react-router-dom";
import { useState, useRef } from "react";

export default function BlogLayout(){
    const navigate=useNavigate();

    const [posts, setPosts]=useState([
        {id:1, title:"첫번째 블로그 Post", content:""},
        {id:2, title:"React Router 학습", content:""},
        {id:3, title:"고급 React Patterns", content:""},
    ]);
    
    const nextId=useRef(4);

    const onAddPost=(_title, _content)=>{
       setPosts([...posts,  {id:nextId.current, title:_title, content:_content}]);
       nextId.current++;
       navigate("/blog");
    }

    return(
        <div>
            <h1>Blog</h1>
            <nav>
            <NavLink to="">Home</NavLink> |
            <NavLink to="create">Create New Post</NavLink>
            </nav>
            <Outlet context={{posts, onAddPost}}/>
        </div>
    );
}