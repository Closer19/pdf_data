import { useOutletContext } from "react-router-dom";

export default function CreatePost(){
    const {onAddPost}=useOutletContext();

    const handleSubmit=(e)=>{
        e.preventDefault();
        const title=e.target.title.value;
        const content=e.target.content.value;
        onAddPost(title, content);        
    }

    return (
        <>
        <h2>Create New Post</h2>
        <form onSubmit={handleSubmit}>
            <label htmlFor="title">Title:</label>
            <input type="text" name="title" id="title"></input><br/>
            <label htmlFor="content">Content:</label>
            <textarea name="content" id="content"></textarea><br/>
            <button type="submit">Create Post</button>
        </form>
        </>
    );
}