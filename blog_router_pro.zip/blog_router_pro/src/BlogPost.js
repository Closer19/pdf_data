import { useParams, useNavigate } from "react-router-dom";

export default function BlogPost(){
    const navigate=useNavigate();
    const {postId}=useParams();
    return(
        <>
        <h2>Blog Post</h2>
        <p>이글은 ID :{postId}번의 글입니다.</p>
        <button onClick={()=>{
            navigate(-1);
        }}>Go Back</button>
        </>

    );
}