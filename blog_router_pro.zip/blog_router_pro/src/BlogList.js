import { useNavigate, useOutletContext } from "react-router-dom";

export default function BlogList() {
  const navigate = useNavigate(); // url을 변경하는 함수를 리턴
  const { posts } = useOutletContext();
  const postList = posts.map((t) => {
    return (
      <li>
        <span
          style={{ cursor:"pointer", color: "blue" }}
          onClick={(e) => {
            navigate("post/" + t.id);
          }}
        >
          {t.title}
        </span>
      </li>
    );
  });

  return (
    <>
      <h2>Blog Post</h2>
      <ul>{postList}</ul>
    </>
  );
}
