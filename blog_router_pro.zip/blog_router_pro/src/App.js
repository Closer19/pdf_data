import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import BlogLayout from './BlogLayout';
import BlogList from './BlogList';
import BlogPost from './BlogPost';
import CreatePost from './CreatePost';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="blog" element={<BlogLayout/>}>
          <Route index element={<BlogList/>}/ >
          <Route path="post/:postId" element={<BlogPost/>}/> 
          <Route path="create" element={<CreatePost/>}/>     
        </Route>
      </Routes>
    </BrowserRouter>   
  );
}

export default App;
