import {createSlice, configureStore} from "@reduxjs/toolkit";
const userInfoSlice=createSlice({
    name: "userInfo",
    initialState:{
        csrfToken:null,
        loginFlag:false,
    },
    reducers:{
        saveCsrfToken:(state, action)=>{
            state.csrfToken=action.payload;
        },
        login:(state)=>{
            state.loginFlag=true;
        },
        logout:(state)=>{
            state.loginFlag=false;
        },
    }
});
const store=configureStore({
    reducer:{
        userInfo:userInfoSlice.reducer,
    }
});
export const {saveCsrfToken, login, logout}=userInfoSlice.actions;
export default  store;