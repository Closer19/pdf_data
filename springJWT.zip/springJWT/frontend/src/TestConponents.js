import {useState} from "react";
import {useSelector} from "react-redux";
import axios from "axios";

export default function TestConponents() {
    const [message, setMessage]=useState("");
    const csrfToken=useSelector(state=>state.userInfo.csrfToken);

    const handleLogout=async (e)=>{
        try{
            const response=await axios.post("http://localhost:8080/logout",{},
                {
                    headers:{
                        "X-CSRF-TOKEN" : csrfToken,
                    },
                    withCredentials:true
                });
            setMessage(response.data);

        }catch(error){
            console.log(error);
            console.log("로그아웃 오류");
        }

    };
    const handleAdminClick=async (e)=>{
        e.preventDefault();
        try{
            const response=await axios.get("http://localhost:8080/admin",
                {withCredentials:true});
            setMessage(response.data);

        }catch(error){
            if(error.response.status===403){
                setMessage("관리자계정만 접근가능합니다.");
            }else if(error.response.data.message){
                setMessage(error.response.data.message);
            }else{
                console.log(error);
                console.log("관리자 요청 실패");
            }

        }

    }
    return (
        <>
            <button onClick={handleLogout}>LOGOUT</button>
            <button onClick={handleAdminClick}>ADMIN</button>
            <h1>{message}</h1>
        </>
    )
}