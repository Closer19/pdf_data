import {useParams} from "react-router-dom";
import {useDispatch, useSelector} from "react-redux";
import {useState} from "react";
import {productUpdate} from "./productSlice";
import {useNavigate} from "react-router-dom";

export default function EditProduct(){
    const {id} = useParams();
    const product = useSelector(state =>
        state.product.pdList.find(t => t.id === Number(id) ? t : null));
    const [state, setState] = useState(product);
    const dispatch=useDispatch();
    const navigate=useNavigate();

    const handleSubmit=(e)=>{
        e.preventDefault();
        dispatch(productUpdate({id:product.id, title:e.target.title.value, price:e.target.price.value, imgsrc:product.imgsrc}));
        console.log(product.id, e.title, e.price);
        navigate("/");
    };

    return(
        <>
            <h2>Edit Product</h2>
            <form onSubmit={handleSubmit}>
                <input type="text" name="title" value={state.title || ""}
                       onChange={(e) => setState(s => ({...s, title: e.target.value}))}></input>
                <input type="text" name="price" value={state.price || ""}
                       onChange={(e) => setState(s => ({...s, price: e.target.value}))}></input>
                <button type="submit">저장</button>
            </form>
        </>
    );
}