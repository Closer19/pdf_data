import {useSelector} from "react-redux";
import {useParams} from "react-router-dom";

export default function DetailProduct(){
    const {id}=useParams();
    const product=useSelector(state=>state.product.pdList.find(t=>t.id===Number(id)? t:null));
    if(product===null){
        console.log("없는 상품입니다.");
    }
    return(
        <>
            <img src={product.imgsrc}/>
            <p>{product.title}</p>
            <p>{product.price}</p>
        </>
    );
}