import {useDispatch} from "react-redux";
import {useRef} from "react";
import {productAdd} from "./productSlice";
import {useNavigate} from "react-router-dom";

export default function NewProduct(){
    const dispatch=useDispatch();
    const navigate=useNavigate();
    const nextId=useRef(3);

    const handleSubmit=(e)=>{
        e.preventDefault();
        dispatch(productAdd({id:nextId.current, title:e.target.title.value, price:e.target.price.value, imgsrc:"http://via.placeholder.com/150x150/0000ff" }));
        nextId.current++;
        navigate("/");
    }

    return(
        <>
            <h2>New Product</h2>
            <form onSubmit={handleSubmit}>
                <input type="text" name="title"></input>
                <input type="text" name="price"></input>
                <button type="submit">저장</button>
            </form>
        </>
    );
}