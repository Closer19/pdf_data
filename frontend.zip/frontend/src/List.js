import {useDispatch, useSelector} from "react-redux";
import {Link} from "react-router-dom";
import {productDelete} from "./productSlice";

export default function List(){
    const pdList=useSelector(state=>state.product.pdList);
    const dispatch=useDispatch();

    const list=pdList.map(t=>(
        <div key={t.id}>
            <Link to={"/detail-product/"+t.id}><img src={t.imgsrc}/></Link>
            <h2>{t.title}</h2>
            <Link to={"/edit-product/"+t.id}>🖋️</Link>️
            <span id={t.id} onClick={()=>dispatch(productDelete(t.id))}>🗑️</span>
        </div>
    ));

    return (
        <>
            <div>
                {list}
            </div>

        </>
    );
}

