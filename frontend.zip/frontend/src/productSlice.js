import {createSlice} from "@reduxjs/toolkit";

const initialState={
    pdList:[{id:1, title:"바지", imgsrc:"http://via.placeholder.com/150x150/ff0000", price:10000},
        {id:2, title:"치마", imgsrc:"http://via.placeholder.com/150x150/00ff00", price:20000}],
    count:2,
}

const productSlice=createSlice({
    name:"product",
    initialState:initialState,
    reducers:{
        productAdd:(state, action)=>{
            state.pdList.push(action.payload);
            state.count++;
        },
        productUpdate:(state, action)=>{
           state.pdList=state.pdList.map(t=>t.id===action.payload.id? action.payload:t);
        },
        productDelete:(state, action)=>{
            state.pdList=state.pdList.filter(t=>t.id!==action.payload);
            state.count--;
        }

    }
    });

export const {productAdd,productUpdate, productDelete }=productSlice.actions;
export default productSlice.reducer;