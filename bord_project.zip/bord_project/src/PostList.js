export default function PostList(props){
    const postList=[];
    if(props.list===null){
        return;
    }
    for(let i=0 ;i<props.list.length; i++){
        const element=<>
        <a key={i} id={props.list[i].id} href={"/"+props.list.mode+"/"} onClick={event=>{
            event.preventDefault();
            props.onPostSelected(event.target.id);
        }}>{props.list[i].title+"(작성자:"+ props.list[i].writer+')'}</a>
        <hr/>
        </>
        postList.push(element);
    }
    return (
        <>
        {postList}
        </>

    );
}