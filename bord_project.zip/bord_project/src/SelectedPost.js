import { useState } from "react";
export default function SelectedPost(props) {
  const [title, setTitle] = useState(props.item.title);
  const [body, setBody] = useState(props.item.body);
  const [writer, setWriter] = useState(props.item.writer);
  return (
    <>
      <form>
        <p>
          <input
            type="text"
            name="title"
            value={title}
            onChange={(event) => {
              setTitle(event.target.value);
            }}
          ></input>
        </p>
        <p>
          <textarea
            name="body"
            rows="30"
            cols="50"
            value={body}
            onChange={(event) => {
              setBody(event.target.value);
            }}
          ></textarea>
        </p>
        <p>
          <input
            type="text"
            name="writer"
            value={writer}
            onChange={(event) => {
              setWriter(event.target.value);
            }}
          ></input>
        </p>
        
        <p>
          <input
            type="button"
            value="수정"
            onClick={(event) => {
              props.onUpdate(props.item.id, title, body, writer);
            }}
          ></input>
          {"   "}
          <input
            type="button"
            value="삭제"
            onClick={(event) => {
              props.onDelete(props.item.id);
            }}
          ></input>
        </p>
      </form>
    </>
  );
}
