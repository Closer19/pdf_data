import {useDispatch, useSelector} from "react-redux";
import {Link} from "react-router-dom";
import {productDelete} from "./productSlice";
import axios from "axios";

export default function List(){
    const pdList=useSelector(state=>state.product.pdList);
    const dispatch=useDispatch();
    const handleDelete=async (e)=>{
        try{
            const response=await axios.delete("http://localhost:8080/product/"+e.target.id,
                {timeout:5000});
            dispatch(productDelete(Number(response.data)));
        }catch(error){
            if(error.code==="ECONNABORTED"){
                console.error("요청시간 초과");
            }
            if(error.response.status===404){
                console.log(error.response.data);
            }
            console.error(error.message);
        }
    }
    const list=pdList.map(t=>(
        <div key={t.id}>
            <Link to={"/detail-product/"+t.id}><img src={t.imgsrc}/></Link>
            <h2>{t.title}</h2>
            <Link to={"/edit-product/"+t.id}>🖋️</Link>️
            <span id={t.id} onClick={handleDelete}>🗑️</span>
        </div>
    ));

    return (
        <>
            <div>
                {list}
            </div>

        </>
    );
}

