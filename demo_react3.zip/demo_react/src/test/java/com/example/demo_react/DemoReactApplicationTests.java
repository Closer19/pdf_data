package com.example.demo_react;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoReactApplicationTests {

	@Test
	void contextLoads() {
	}

}
