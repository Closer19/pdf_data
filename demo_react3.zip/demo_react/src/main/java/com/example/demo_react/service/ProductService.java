package com.example.demo_react.service;

import com.example.demo_react.data.dao.ProductDAO;
import com.example.demo_react.data.dto.ProductDTO;
import com.example.demo_react.data.entity.Product;
import com.example.demo_react.data.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ProductService {
    private final ProductDAO productDAO;

    public List<ProductDTO> getAllProduct() {
        List<Product> productList = this.productDAO.getAllProduct();
        List<ProductDTO> productDTOList = new ArrayList<>();
        for (Product product : productList) {
            ProductDTO productDTO = ProductDTO.builder()
                    .id(product.getId())
                    .price(product.getPrice())
                    .title(product.getTitle())
                    .imgsrc(product.getImgsrc())
                    .build();

            productDTOList.add(productDTO);
        }

        return productDTOList;
    }

    public ProductDTO saveProduct(ProductDTO productDTO) {
        Product newProduct=this.productDAO.saveProduct(productDTO.getTitle(),
                productDTO.getPrice());

        ProductDTO retProductDTO=ProductDTO.builder()
                .id(newProduct.getId())
                .title(newProduct.getTitle())
                .price(newProduct.getPrice())
                .imgsrc(newProduct.getImgsrc())
                .build();
        return retProductDTO;
    }

    public ProductDTO updateProduct(ProductDTO productDTO) {
            Product product=this.productDAO.getProduct(productDTO.getId());

            if(product!=null) {
                Product updateProduct=this.productDAO.updateProduct(productDTO.getId(),
                        productDTO.getTitle(), productDTO.getPrice());
                ProductDTO updateProductDTO=ProductDTO.builder()
                        .id(updateProduct.getId())
                        .title(updateProduct.getTitle())
                        .price(updateProduct.getPrice())
                        .imgsrc(updateProduct.getImgsrc())
                        .build();
                return updateProductDTO;
            }
        return null;
    }

    public Integer deleteProduct(Integer id) {
        Product product=this.productDAO.getProduct(id);
        if(product!=null) {
            return this.productDAO.deleteProduct(id);
        }
        return -1;
    }




}
