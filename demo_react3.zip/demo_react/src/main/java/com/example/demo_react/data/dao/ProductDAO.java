package com.example.demo_react.data.dao;

import com.example.demo_react.data.entity.Product;
import com.example.demo_react.data.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@RequiredArgsConstructor
@Service
public class ProductDAO {
    private final ProductRepository productRepository;

    public List<Product> getAllProduct() {
        return productRepository.findAll();
    }

    public Product saveProduct(String title, Integer price) {
        Product newProduct = Product.builder()
                .title(title)
                .price(price)
                .imgsrc("http://via.placeholder.com/150x150/00ff00")
                .created(LocalDateTime.now())
                .description("생성")
                .build();
        this.productRepository.save(newProduct);
        return newProduct;
    }

    public Product getProduct(Integer id) {
        Optional<Product> product = this.productRepository.findById(id);
        if(product.isPresent()) {
            return product.get();
        }
        return null;
    }

    public Product updateProduct(Integer id, String title, Integer price) {
        Product product = this.getProduct(id);
        if(product != null) {
            product.setTitle(title);
            product.setPrice(price);
            product.setCreated(LocalDateTime.now());
            product.setDescription("수정됨");
            this.productRepository.save(product);
            return product;
        }
        return null;
    }

    public Integer deleteProduct(Integer id) {
        this.productRepository.deleteById(id);
        return id;
    }

}
