package com.example.demo_react.controller;

import com.example.demo_react.data.entity.Product;
import com.example.demo_react.data.dto.ProductDTO;
import com.example.demo_react.data.repository.ProductRepository;
import com.example.demo_react.service.ProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@RequiredArgsConstructor
public class ProductController {
    private final ProductService productService;

    @GetMapping(value="/product-list")
    public ResponseEntity<List<ProductDTO>> getProductList() {
        List<ProductDTO> productDTOList=this.productService.getAllProduct();
        return ResponseEntity.status(HttpStatus.OK).body(productDTOList);
    }

    @PostMapping(value="/product")
    public ResponseEntity<ProductDTO> addProduct(@RequestBody ProductDTO product) {
        ProductDTO productDTO=this.productService.saveProduct(product);
        return ResponseEntity.status(HttpStatus.OK).body(productDTO);
    }

    @PutMapping(value="/product")
    public ResponseEntity<ProductDTO> updateProduct(@RequestBody ProductDTO productDTO) {
        ProductDTO updateProductDTO=this.productService.updateProduct(productDTO);
        if(updateProductDTO==null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
        return ResponseEntity.status(HttpStatus.OK).body(updateProductDTO);
    }

    @DeleteMapping(value="/product/{id}")
    public ResponseEntity<String> deleteProduct(@PathVariable("id") Integer id) {
        Integer deleteId=this.productService.deleteProduct(id);
        if(deleteId==-1) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("없는 아이디");
        }
        return ResponseEntity.status(HttpStatus.OK).body(String.valueOf(deleteId));
    }

}
