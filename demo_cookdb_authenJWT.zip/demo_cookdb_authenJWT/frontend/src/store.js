import {createSlice, configureStore} from "@reduxjs/toolkit";

const userInfoSlice=createSlice({
    name:"userInfo",
    initialState:{
        userInfoList:[],
        count:0,
        loginFlag:false,
        jwtToken:null,
        role:null,
    },
    reducers: {
        addUserInfo: (state, action) => {
            state.userInfoList.push(action.payload);
            state.count++;
        },
        clearUserInfo: (state) => {
            state.userInfoList = [];
            state.count = 0;
        },
        login: (state) => {
            state.loginFlag = true;
        },
        logout: (state) => {
            state.loginFlag = false;
            state.jwtToken=null;
        },
        saveJwtToken:(state, action)=>{
            state.jwtToken=action.payload;
        },
        saveRole:(state, action)=>{
            state.role=action.payload;
        }
    }
});

const store=configureStore({
    reducer:{
        userInfo:userInfoSlice.reducer,
    }
});

export const {addUserInfo,clearUserInfo, login, logout, saveJwtToken, saveRole }=userInfoSlice.actions;
export default store;