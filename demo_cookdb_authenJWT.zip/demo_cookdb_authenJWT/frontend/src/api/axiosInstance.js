import axios from "axios";

import store from "../store";

const apiClient=axios.create({
    baseURL:"http://localhost:8080",
    headers:{
        "Content-Type" : "application/json",

    },
    // withCredentials: true,
// timeout:3000,
});



apiClient.interceptors.request.use((config) => {
    // 1. 요청 데이터가 URLSearchParams 타입인지 확인
    if (config.data instanceof URLSearchParams) {
        config.headers["Content-Type"] = "application/x-www-form-urlencoded";
    }
    const jwtToken=store.getState().userInfo.jwtToken;
    config.headers["authorization"]=jwtToken;

    return config; // 수정된 config 반환
}, (error) => {
    // 요청을 가로채는 중에 에러 발생 시 처리
    return Promise.reject(error);
});


export default apiClient;