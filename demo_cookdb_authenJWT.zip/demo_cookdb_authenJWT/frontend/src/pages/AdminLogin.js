import React, {useState} from "react";
import {useNavigate} from "react-router-dom";
import apiClient from "../api/axiosInstance";
import {useDispatch, useSelector} from "react-redux";
import {login, saveJwtToken, saveRole} from "../store";

import errorDisplay from "../util/errorDisplay";

export default function AdminLogin(){
    const [adminName, setAdminName] = useState("");
    const [adminPassword, setAdminPassword] = useState("");
    const navigate=useNavigate();
    const dispatch=useDispatch();
    const jwtToken=useSelector(state=>state.userInfo.jwtToken);

    const handleAdminLogin= async (e)=>{
        e.preventDefault();
        try {
            const response = await apiClient.post("/login",
                new URLSearchParams({username:"admin"+adminName , password:adminPassword}),
            );
            const role=response.data.role;
            await dispatch(saveRole(role));
            const token=response.headers["authorization"];
            await dispatch(saveJwtToken(token));
            await dispatch(login());
            navigate("/home");

        } catch (error) {
            errorDisplay(error);
            navigate("/");
        }
    };

    return (
        <>
            <form onSubmit={handleAdminLogin}>
                <p>관리자 아이디 : <input
                    type="text"
                    placeholder="Admin Name"
                    name="adminName"
                    value={adminName}
                    onChange={(e) => setAdminName(e.target.value)}
                />
                </p>
                <p>관리자 비밀번호 : <input
                    type="password"
                    placeholder="Admin Password"
                    name="password"
                    value={adminPassword}
                    onChange={(e) => setAdminPassword(e.target.value)}
                />
                </p>
                <button type="submit">로그인</button>
            </form>
        </>
    );
}
