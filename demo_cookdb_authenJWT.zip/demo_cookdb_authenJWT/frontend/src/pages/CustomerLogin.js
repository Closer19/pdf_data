import {login, saveJwtToken, saveRole} from "../store";
import apiClient from "../api/axiosInstance";
import {useNavigate} from "react-router-dom";
import {useState} from "react";
import {useDispatch, useSelector} from "react-redux";

export default function CustomerLogin(){
    const [customerName, setCustomerName] = useState("");
    const [customerPassword, setCustomerPassword] = useState("");

    const navigate=useNavigate();
    const dispatch=useDispatch();
    const jwtToken=useSelector(state=>state.userInfo.jwtToken);

    const handleCustomerLogin= async (e)=>{
        e.preventDefault();
        try {
            const response = await apiClient.post("/login",
                new URLSearchParams({username:customerName , password:customerPassword}),
            );

            const role=response.data.role;
            await dispatch(saveRole(role));
            const token=response.headers["authorization"];
            await dispatch(saveJwtToken(token));
            await dispatch(login());
            navigate("/home");

        } catch (error) {
            if(error.response){
                console.log(error.response.data);
                alert(error.response.data.error);
                navigate("/");
            }
        }
    };
    return(
        <>
            <form onSubmit={handleCustomerLogin}>
                <p>고객 아이디 : <input
                    type="text"
                    placeholder="customer Name"
                    name="customerName"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                />
                </p>
                <p>고객 비밀번호 : <input
                    type="password"
                    placeholder="customer Password"
                    name="customerPassword"
                    value={customerPassword}
                    onChange={(e) => setCustomerPassword(e.target.value)}
                />
                </p>
                <button type="submit">로그인</button>
            </form>
        </>

    );
}