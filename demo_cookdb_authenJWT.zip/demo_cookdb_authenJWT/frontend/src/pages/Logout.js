import {useEffect} from "react";
import apiClient from "../api/axiosInstance";
import {useDispatch, useSelector} from "react-redux";
import {logout, saveJwtToken} from "../store";
import {useNavigate} from "react-router-dom";

export default function Logout(){
   const dispatch=useDispatch();
   const navigate=useNavigate();

    useEffect(() => {
        // 컴포넌트가 마운트된 후 navigate()를 호출

        dispatch(logout());
        navigate("/");
    }, [navigate]);

    return(
        <>
        </>
    );
}