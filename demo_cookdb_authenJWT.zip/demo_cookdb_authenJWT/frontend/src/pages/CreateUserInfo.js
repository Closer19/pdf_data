import {NavLink, Outlet, useNavigate} from "react-router-dom";
import {useSelector} from "react-redux";
import {useEffect} from "react";

export default function CreateUserInfo(){
    const role=useSelector(state=>state.userInfo.role);
    const navigate=useNavigate();

    useEffect(() => {
        if (role !== "ROLE_ADMIN") {
            alert("관리자 계정만 접근할 수 있는 메뉴입니다.");
            navigate(-1); // 이전 페이지로 이동
        }
    }, [role, navigate]); // roll이나 navigate가 변경될 때 실행

    return (
        <>
            <hr/>
            <NavLink to={"/create-userinfo/join"}>가입 정보 추가</NavLink>&nbsp;&nbsp;&nbsp;
            <NavLink to={"/create-userinfo/add-buyinfo"}>구매 기록 추가</NavLink>
            <hr/>
            <Outlet></Outlet>
        </>
    );
}