export default function Home(){
    return (
        <>
            <h2>고객 관리 홈입니다.</h2>
        </>
    );
}