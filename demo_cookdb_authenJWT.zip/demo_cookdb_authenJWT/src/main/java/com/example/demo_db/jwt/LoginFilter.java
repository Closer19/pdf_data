package com.example.demo_db.jwt;



import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.FilterChain;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import java.io.IOException;
import java.util.*;

@RequiredArgsConstructor
public class LoginFilter extends UsernamePasswordAuthenticationFilter {
    private final AuthenticationManager authenticationManager;
    private final JwtUtil jwtUtil;

    @Override
    public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response) throws AuthenticationException{
//        setFilterProcessesUrl("/admin-login");
        String username = obtainUsername(request);
        String password = obtainPassword(request);
        //클라이언트 요청에서 username, password 추출

        UsernamePasswordAuthenticationToken authRequest = new UsernamePasswordAuthenticationToken(username, password, null);
        //스프링 시큐리티에서 username과 password를 검증하기 위해서는 token에 담아야 함
        return authenticationManager.authenticate(authRequest);
    }

    @Override
    public void successfulAuthentication(HttpServletRequest request, HttpServletResponse response, FilterChain chain, Authentication authentication) throws IOException {
        UserDetails  authen=(UserDetails)authentication.getPrincipal();
        String username=authen.getUsername();

        Collection<? extends GrantedAuthority> authorities = authen.getAuthorities();
        Iterator<? extends GrantedAuthority> iterator = authorities.iterator();
        GrantedAuthority auth = iterator.next();
        String role = auth.getAuthority();

        Map<String, String> responseMap = new HashMap<>();
        responseMap.put("role", role);

        ObjectMapper mapper = new ObjectMapper();
        String jsonmessage = mapper.writeValueAsString(responseMap);

        String token=this.jwtUtil.CreateJwt(username, role, 60 * 10 * 1000L);
        response.addHeader("authorization","Bearer "+token);
//        "Bearer" : 클라이언트가 별도의 인증 정보를 제공하지 않고, 토큰만으로 서버에 요청을 인증할 수 있는 방식이라는 의미
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(jsonmessage);
    }

    @Override
    public void unsuccessfulAuthentication(HttpServletRequest request, HttpServletResponse response, AuthenticationException failed) throws IOException {
        Map<String, Object> responseData = new HashMap<>();
        responseData.put("error", "로그인 실패");

        ObjectMapper objectMapper = new ObjectMapper();
        String jsonmessage = objectMapper.writeValueAsString(responseData);

        response.setStatus(401); // HTTP 401 Unauthorized
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(jsonmessage);
    }
}

