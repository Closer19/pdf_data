package com.login.authentication.Controller;

import com.login.authentication.Repository.UserEntityRepository;
import com.login.authentication.data.UserEntity;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequiredArgsConstructor
public class UserLoginController {
    private final UserEntityRepository userEntityRepository;
    private final PasswordEncoder passwordEncoder;

    @PostMapping(value = "/join")
    public ResponseEntity<String> join(@RequestBody UserEntity userEntity) {
        String password = this.passwordEncoder.encode(userEntity.getPassword());
        userEntity.setPassword(password);
        this.userEntityRepository.save(userEntity);
        return ResponseEntity.status(HttpStatus.CREATED).body("회원이 되신걸 환영합니다 👻");
    }

    @GetMapping(value = "/admin")
    public ResponseEntity<String> admin() {
        return ResponseEntity.status(HttpStatus.OK).body("관리자입니다.");
    }

    @GetMapping(value = "/csrf-token")
    public ResponseEntity<Map<String, String>> csrfToken(HttpServletRequest request) {
        CsrfToken csrfToken = (CsrfToken) request.getAttribute(CsrfToken.class.getName());
        Map<String, String> tokenMap = new HashMap<>();
        tokenMap.put("token", csrfToken.getToken());
        return ResponseEntity.status(HttpStatus.OK).body(tokenMap);
    }
}