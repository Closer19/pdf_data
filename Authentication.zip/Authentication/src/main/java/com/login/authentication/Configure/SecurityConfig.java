package com.login.authentication.Configure;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.login.authentication.component.CustomAuthenticationEntryPoint;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.web.cors.CorsConfiguration;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Configuration
@EnableWebSecurity
@RequiredArgsConstructor
public class SecurityConfig {
    private final CustomAuthenticationEntryPoint customAuthenticationEntryPoint;

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationSuccessHandler loginSuccessHandler() {
        return (request, response, authentication) -> {
            Map<String, Object> responseData = new HashMap<>();
            responseData.put("result", "로그인 성공");

            Object principal=authentication.getPrincipal();
            if(principal instanceof UserDetails) {
                UserDetails userDetails = (UserDetails) principal;
                String username=userDetails.getUsername();
                responseData.put("username", username);
                Collection<? extends GrantedAuthority> authorities = userDetails.getAuthorities();
                authorities.forEach(authority -> {
                    responseData.put("Authority", authority.getAuthority());
                });
            }

            CsrfToken csrfToken = (CsrfToken) request.getAttribute(CsrfToken.class.getName());
            responseData.put("token", csrfToken.getToken());

            ObjectMapper objectMapper = new ObjectMapper();
            String jsonMessage = objectMapper.writeValueAsString(responseData);

            response.setStatus(HttpStatus.OK.value());
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write(jsonMessage);
        };
    }

    @Bean
    public AuthenticationFailureHandler loginFailureHandler() {
        return (request, response, authentication) -> {

            Map<String, Object> responseData = new HashMap<>();
            responseData.put("result", "로그인 실패");

            ObjectMapper objectMapper = new ObjectMapper();
            String jsonMessage = objectMapper.writeValueAsString(responseData);

            response.setStatus(401);
            response.setContentType("application/json");

            response.setCharacterEncoding("UTF-8");
            response.getWriter().write(jsonMessage);

        };
    }
    @Bean
    public LogoutSuccessHandler logoutHandler(){
        return (request, response, authentication) -> {
           response.setStatus(HttpStatus.OK.value());
           response.getWriter().write("Logout success!!");

        };
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
//        http.csrf(csrf->csrf.disable())
             http.cors(cors->{
                })
                .authorizeHttpRequests(authorize->
//                        authorize.requestMatchers("/**").permitAll()
//                        authorize.requestMatchers("/", "login", "join").permitAll()
//                                .requestMatchers("/list").hasRole("ADMIN")
                        authorize.requestMatchers("/","/login","/join", "/csrf-token").permitAll()
                                .requestMatchers("/admin").hasRole("ADMIN")
                                .anyRequest().authenticated()

                );

        http.formLogin(form->{
            form.loginProcessingUrl("/login")
                .successHandler(loginSuccessHandler())
                .failureHandler(loginFailureHandler());
        });

        http.logout(logout->logout.logoutUrl("/logout")
                .logoutSuccessHandler(logoutHandler())
                .addLogoutHandler((request, response, authentication)->{
                    if(request.getSession()!=null){
                        request.getSession().invalidate();
                    }
                }).deleteCookies("JSESSIONID"));

        http.cors(cors -> cors.configurationSource(request -> {
            // CORS 설정을 위한 CorsConfiguration 객체 생성
            CorsConfiguration config = new CorsConfiguration();
            // 자격 증명(쿠키 등)을 허용하도록 설정
            config.setAllowCredentials(true);
            // 허용할 출처를 설정 (여기서는 localhost:3000)
//            config.setAllowedOrigins(List.of("https://localhost:3000", "http://localhost:3001"));
            config.addAllowedOrigin("http://localhost:3000");
            // 모든 헤더를 허용
            config.addAllowedHeader("*");
            // 모든 HTTP 메서드를 허용 (GET, POST, PUT 등)
            config.addAllowedMethod("*");
            // 설정한 CORS 구성을 반환
            return config;
        }));

        http.exceptionHandling(exception->
                exception.authenticationEntryPoint(customAuthenticationEntryPoint)
                );

        return http.build();
    }
}
