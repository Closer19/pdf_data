package com.login.authentication.Service;

import com.login.authentication.Repository.UserEntityRepository;
import com.login.authentication.data.UserEntity;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.core.userdetails.User; // 추가된 import
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class UserLoginService implements UserDetailsService {
    private final UserEntityRepository entityRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Optional<UserEntity> userEntity = this.entityRepository.findById(username); // 메서드 수정

        if (userEntity.isEmpty()) {
            throw new UsernameNotFoundException(username);
        }

        UserEntity user = userEntity.get();
        List<GrantedAuthority> grantedAuthorities = new ArrayList<>();
        if(user.getUsername().equals("bbb")) {
            grantedAuthorities.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
        }else{
            grantedAuthorities.add(new SimpleGrantedAuthority("ROLE_USER"));
        }
        return new User(user.getUsername(), user.getPassword(), grantedAuthorities);
    }
}
