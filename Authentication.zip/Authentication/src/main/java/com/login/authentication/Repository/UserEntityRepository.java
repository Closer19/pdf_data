package com.login.authentication.Repository;

import com.login.authentication.data.UserEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserEntityRepository extends JpaRepository<UserEntity, String> {


}
