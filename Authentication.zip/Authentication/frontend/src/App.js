import './App.css';
import {useEffect} from "react";
import TestConponents from "./TestConponents";
import Login from './Login';
import axios from "axios";
import {useDispatch, useSelector} from "react-redux";
import {saveCsrfToken} from "./store";

function App() {
  const loginFlag=useSelector(state=>state.userInfo.loginFlag);
  const dispatch=useDispatch();
  useEffect(()=>{
    const fetchData=async ()=>{
      try{
        const response=await axios.get("http://localhost:8080/csrf-token",
            {withCredentials:true});
        await dispatch(saveCsrfToken(response.data.token));
        console.log("csrf토큰 :", response.data.token);

      }catch(error){
        console.log(error);
        console.log("csrf 토큰 발급에러");
      }
    };
    fetchData();
  }, []);

  return (
    <>
      {!loginFlag && <Login></Login>}
      {loginFlag && <TestConponents/>}
    </>
  );
}

export default App;
