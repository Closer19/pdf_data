import './App.css';
import {useState} from "react";
import TestConponents from "./TestConponents";
import Login from './Login';

function App() {
  const [isLogin, setIsLogin] = useState(false)
  return (
    <>
      {!isLogin && <Login onLogin={() => setIsLogin(true)}></Login>}
      {isLogin && <TestConponents/>}
    </>
  );
}

export default App;
