import {useState} from "react";
import axios from "axios";

export default function TestConponents() {
    const [message, setMessage]=useState("");

    const handleLogout=async (e)=>{
        try{
            const response=await axios.get("http://localhost:8080/logout",{
                withCredentials:true,
            });
            setMessage(response.data);

        }catch(error){
            console.log(error);
            console.log("로그아웃 오류");
        }

    };
    const handleAdminClick=async (e)=>{
        e.preventDefault();
        try{
            const response=await axios.get("http://localhost:8080/admin",
                {withCredentials:true});
            setMessage(response.data);

        }catch(error){
            console.log(error);
            console.log("관리자 요청 실패");
        }

    }
    return (
        <>
            <button onClick={handleLogout}>LOGOUT</button>
            <button onClick={handleAdminClick}>ADMIN</button>
            <h1>{message}</h1>
        </>
    )
}