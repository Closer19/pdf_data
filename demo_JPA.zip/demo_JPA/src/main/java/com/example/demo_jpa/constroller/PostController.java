package com.example.demo_jpa.constroller;

import com.example.demo_jpa.data.PostEntity;
import com.example.demo_jpa.data.PostEntityRepository;
import com.example.demo_jpa.data.UserEntity;
import com.example.demo_jpa.data.UserEntityRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class PostController {
    private final UserEntityRepository userRepository;
    private final PostEntityRepository postRepository;

    @GetMapping(value="/postlist")
    public ResponseEntity<List<PostEntity>> getPostList() {
        return ResponseEntity.ok(postRepository.findAll());
    }

    @GetMapping(value="/addlist/{title}/{id}")
    public ResponseEntity<PostEntity> addPost(@PathVariable String title, @PathVariable Long id) {
        PostEntity post=new PostEntity();
        post.setTitle(title);
        UserEntity user=this.userRepository.findById(id).get();
        post.setUser(user);
        PostEntity savePost=postRepository.save(post);
        return ResponseEntity.ok(savePost);
    }

    @GetMapping(value="userlist")
    public ResponseEntity<List<PostEntity>> getUserList() {
        List<PostEntity> posts=this.userRepository.findById(1L).get().getPosts();
        return ResponseEntity.ok(posts);
    }



}
