package com.example.demo_jpa.constroller;

import com.example.demo_jpa.data.*;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class MadangController {
    private final BookRepository bookRepository;
    private final CustomerRepogitory customerRepogitory;
    private final OrderRepository orderRepository;

    @GetMapping(value="/customerlist")
    public ResponseEntity<List<Customer>> getCustomerList() {
        List<Customer> customerList = this.customerRepogitory.findAll();
        return ResponseEntity.ok(customerList);
    }

    @GetMapping(value="/booklist")
    public ResponseEntity<List<Book>> getBookList() {
        List<Book> bookList = this.bookRepository.findAll();
        return ResponseEntity.ok(bookList);
    }



}
