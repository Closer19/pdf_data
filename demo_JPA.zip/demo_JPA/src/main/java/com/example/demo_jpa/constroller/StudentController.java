package com.example.demo_jpa.constroller;

import com.example.demo_jpa.data.Course;
import com.example.demo_jpa.data.CourseRepository;
import com.example.demo_jpa.data.Student;
import com.example.demo_jpa.data.StudentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class StudentController {
    private final StudentRepository studentRepository;
    private final CourseRepository courseRepository;

    @GetMapping(value="/addstudent/{name}")
    public ResponseEntity<Student> addStudent(@PathVariable String name) {
        Student student = new Student();
        student.setName(name);

        Course course1 = this.courseRepository.findById(1L).get();
        Course course2 = this.courseRepository.findById(2L).get();

        student.getCourseList().add(course1);
        student.getCourseList().add(course2);
        course1.getStudentList().add(student);
        course2.getStudentList().add(student);
        Student saveStudent=this.studentRepository.save(student);
        return ResponseEntity.ok(saveStudent);
    }

    @GetMapping(value="/courselist")
    public ResponseEntity<List<Course>> getCourseList() {
        List<Course> courseList=this.courseRepository.findAll();
        return ResponseEntity.ok(courseList);
    }



}
