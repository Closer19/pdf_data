package com.example.demo_jpa.data;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

@Getter
@Setter
@Entity
@Table(name = "book", schema = "madang")
public class Book {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "bookid", nullable = false)
    private Integer id;

    @Column(name = "bookname", nullable = false, length = 20)
    private String bookname;

    @Column(name = "publisher", nullable = false, length = 10)
    private String publisher;

    @Column(name = "price", nullable = false)
    private Integer price;

    @OneToMany(mappedBy = "bookid")
    private List<Order> orders = new ArrayList<>();

}