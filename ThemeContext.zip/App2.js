import { useContext } from 'react';
import { ThemeProvider, ThemeContext } from './ThemeContext';

const Header = () => {
    const { isDarkMode } = useContext(ThemeContext);
    return (
        <header style={{
            backgroundColor: isDarkMode ? '#444' : '#eee',
            padding: '10px'
        }}>
            <h2>{isDarkMode ? 'Dark Theme Header' : 'Light Theme Header'}</h2>
        </header>
    );
};

const ThemedComponent = () => {
    const { isDarkMode, toggleTheme } = useContext(ThemeContext);

    return (
        <div style={{
            backgroundColor: isDarkMode ? '#333' : '#FFF',
            color: isDarkMode ? '#FFF' : '#333',
            padding: '20px',
            textAlign: 'center'
        }}>
            <h1>{isDarkMode ? 'Dark Mode' : 'Light Mode'}</h1>
            <button onClick={toggleTheme}>
                Toggle Theme
            </button>
            <Header />
        </div>
    );
};

const App2 = () => {
    return (
        <ThemeProvider>
            <ThemedComponent />
        </ThemeProvider>
    );
};

export default App2;
