import { createContext, useState } from 'react';

export const ThemeContext = createContext();

export const ThemeProvider = ({ children }) => {
    const [isDarkMode, setIsDarkMode] = useState(false);

    const toggleTheme = () => {
        // setIsDarkMode(prevMode => !prevMode);         
        //함수형 업데이트.. setState함수가 비동기적으로 실행될때 전달된 함수가 호출되고 그 결과값으로 상태값이 저장된다.
        setIsDarkMode(!isDarkMode); 
    };

    return (
        <ThemeContext.Provider value={{ isDarkMode, toggleTheme }}>
            {children}
        </ThemeContext.Provider>
    );
};