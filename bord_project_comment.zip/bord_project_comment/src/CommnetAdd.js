export default function CommentAdd(props){    
    return (
        <>
        <form onSubmit={event=>{
            event.preventDefault();
            const comment=event.target.comment.value;
            const writer=event.target.commentWriter.value;
            console.log(comment, writer);
            props.onCommentAdd(comment, writer);            
        }}>           
              <input
                type="text"
                name="comment"
                placeholder="댓글을 작성하세요"              
              ></input>                     
              <input
                type="text"
                name="commentWriter"
                placeholder="댓글작성자"
               ></input>             
              <input
                type="submit"
                value="등록"                            
              ></input>
             
        </form>
        </>

    );
}