export default function CommentsList(props) {
  const commentList = [];
  for (let i = 0; i < props.comments.length; i++) {
    const c = props.comments[i];
    const item = (
      <div key={i}>
        {c.comment + "(" + c.writer + ")   "}{" "}
        <a 
          href="/comment/delete"
          onClick={(event) => {
            event.preventDefault();
            props.onDelete(c.id);
          }}
        >
          삭제
        </a>
      </div>
    );
    commentList.push(item);
  }
  return (
    <>
      <div>{commentList}</div>
    </>
  );
}
