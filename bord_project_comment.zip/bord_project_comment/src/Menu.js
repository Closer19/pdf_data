import "./menu.css";

export default function Menu(props){
    const menu=[];
    for(let i=0;i<props.menu.length; i++){
        const item=props.menu[i];
        const element=<a key={i} href={"/menu/"+item.mode}
         style={{ marginRight: '10px' }} onClick={event=>{
            event.preventDefault();
            props.onSelected(item.mode);
         }}>{item.title}</a>
        menu.push(element);
    }
    
    return (
        <>
        <div className="menu">
        {menu}
        </div>
        <hr/>
        </>
        
    );
}