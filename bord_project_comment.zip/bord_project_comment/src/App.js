import logo from "./logo.svg";
import "./App.css";
import Header from "./Header";
import Menu from "./Menu";
import { useState, useRef } from "react";
import PostList from "./PostList";
import PostWrite from "./PostWrite";
import SelectedPost from "./SelectedPost";

function App() {
  const [mode, setMode] = useState("LIST");
  const [id, setId] = useState(0);
  const nextId = useRef(2);

  const mainTitle = "글목록";
  let contents = null;
  let menuTitle = null;
  const [postList, setPostList] = useState([
    { id: 1, title: "반갑습니다", body: "Hello", writer:"김진아", comments:[]},
  ]);
  const menu_List = [
    { id: 1, mode: "write", title: "글쓰기" },
    { id: 2, mode: "update", title: "수정하기" },
    { id: 3, mode: "delete", title: "삭제하기" },
    { id: 4, mode: "postList", title: "목록으로" },
  ];

  switch (mode) {
    case "LIST":
      {
        menuTitle = (
          <Menu
            menu={menu_List.slice(0, 1)}
            onSelected={(_mode) => {
              if (_mode === "write") {
                setMode("WRITE");
              }
            }}
          ></Menu>
        );
        contents = (
          <PostList
            list={postList}
            onPostSelected={(_id) => {
              setId(Number(_id));
              setMode("READ");
            }}
          ></PostList>
        );
      }
      break;
    case "READ":
      {
        menuTitle = (
          <Menu
            menu={menu_List.slice(3)}
            onSelected={(_mode) => {
              if (_mode === "postList") {
                setMode("LIST");
              }
            }}
          ></Menu>
        );
        const item = postList.find((item) => item.id === Number(id));
        contents =           
          <SelectedPost
            item={item}
            onUpdate={(_id, _title, _body, _writer, _comments) => {
              const newItem = { id: _id, title: _title, body: _body, writer:_writer, comments:_comments};
              const newItemList = [...postList];
              for (let i = 0; i < newItemList.length; i++) {
                if (newItemList[i].id === Number(_id)) {
                  newItemList[i] = newItem;
                  break;
                }
              }
              setPostList(newItemList);
              setMode("LIST");
            }}
            onDelete={(_id) => {
              const newItemList = [];
              for (let i = 0; i < postList.length; i++) {
                if (postList[i].id !== _id) {
                  newItemList.push(postList[i]);
                }
              }
              setPostList(newItemList);
              setMode("LIST");
            }}
            onCommentUpdate={(_comments)=>{
              for(let i=0; i<postList.length; i++){
                if(postList[i].id===Number(id)){
                  postList[i].comments=_comments;
                  break;
                }
              }              
            }}
          ></SelectedPost>;
        
      }
      break;
    case "WRITE":
      {
        menuTitle = (
          <Menu
            menu={menu_List.slice(3)}
            onSelected={(_mode) => {
              if (_mode === "postList") {
                setMode("LIST");
              }
            }}
          ></Menu>
        );
        contents = (
          <PostWrite
            onSave={(_title, _body, _writer) => {
              const listItem = { id: nextId.current, title: _title, body: _body, writer:_writer, comments:[]};
              let newPostList = [];
              newPostList = [...postList];
              newPostList.push(listItem);
              nextId.current++;
              setPostList(newPostList);
              setMode("LIST");
            }}
          ></PostWrite>
        );
      }
      break;
  }

  return (
    <div>
      <Header title={mainTitle}></Header>
      {menuTitle}
      {contents}
    </div>
  );
}

export default App;
