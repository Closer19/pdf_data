import { useState, useRef } from "react";
import CommentsList from "./CommentsList";
import CommentAdd from "./CommnetAdd";

export default function SelectedPost(props) {
  const [title, setTitle] = useState(props.item.title);
  const [body, setBody] = useState(props.item.body);
  const [writer, setWriter] = useState(props.item.writer);
  const [comments, setComments]= useState(props.item.comments);
  const nextCommentId = useRef(props.item.comments.length+1);

  return (
    <>
      <form>
        <p>
          <input
            type="text"
            name="title"
            value={title}
            onChange={(event) => {
              setTitle(event.target.value);
            }}
          ></input>
        </p>
        <p>
          <textarea
            name="body"
            rows="30"
            cols="50"
            value={body}
            onChange={(event) => {
              setBody(event.target.value);
            }}
          ></textarea>
        </p>
        <p>
          <input
            type="text"
            name="writer"
            value={writer}
            onChange={(event) => {
              setWriter(event.target.value);
            }}
          ></input>
        </p>        
        <p>
          <input
            type="button"
            value="수정"
            onClick={(event) => {
              props.onUpdate(props.item.id, title, body, writer, comments);
            }}
          ></input>
          {"   "}
          <input
            type="button"
            value="삭제"
            onClick={(event) => {
              props.onDelete(props.item.id);
            }}
          ></input>          
        </p>
        </form>
      
          <CommentsList comments={props.item.comments} onDelete={(_id)=>{
            const c=props.item.comments;
            const newList=[];
            for(let i=0; i<comments.length; i++){
              if(comments[i].id!==(_id)){
                newList.push(comments[i]);
              }
            }
            setComments(newList);
            props.onCommentUpdate(newList);
          }} ></CommentsList>
     
        <CommentAdd onCommentAdd={(_comment, _writer)=>{
          const comment={id:nextCommentId.current, comment:_comment, writer:_writer};
          const newList=[...comments];
          newList.push(comment);          
          setComments(newList);
          nextCommentId.current++;
          props.onCommentUpdate(newList);
        }}></CommentAdd>
        
      
    </>
  );
}
