import "./postWrite.css"
export default function PostWrite(props){
    return (
        <>
        <form onSubmit={event=>{            
            event.preventDefault();
            const title=event.target.title.value;
            const body=event.target.body.value;
            const writer=event.target.writer.value;
            props.onSave(title, body, writer);            
        }}>
            <p><input type='text' name="title" placeholder="제목입력"></input></p>
            <p><textarea name="body" placeholder="내용입력" rows="30" cols="50"></textarea></p>
            <input type="text" name="writer" placeholder="작성자이름"></input>
            <p><input type="submit" value="저장"></input></p>
        </form>
        </>

    );
}