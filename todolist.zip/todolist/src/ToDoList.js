import { useOutletContext } from "react-router-dom";

export default function ToDoList(){
    const {todos, removeToDo}=useOutletContext();
    const list=todos.map((t)=>{
        return(
            <li key={t.id}><span style={{textDecoration:t.completed? "line-through":"none"}}>{t.task}</span>
            <button onClick={()=>{
                removeToDo(t.id);
            }}>완료</button>
            </li>
        );
    });
    return(
        <>
        <h2>To-Do 목록</h2>
        <ul>
        {list}
        </ul>
        </>
            );
}