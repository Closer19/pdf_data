import { NavLink, Outlet, useNavigate } from "react-router-dom";
import {useState, useRef} from "react";

export default function ToDoLayout(){
    const [todos, setToDos]=useState([
        {id:1, task:"React 공부하기", completed:false},
        {id:2, task:"운동하기", completed:false},
    ]);
    const nextId=useRef(3);
    const navigate=useNavigate();

    const addToDo=(_task)=>{
        setToDos([...todos, {id:nextId.current, task:_task, completed:false}]);
        nextId.current++;
        navigate("/todo");
    }

    const removeToDo=(_id)=>{
        // setToDos(todos.filter(todo=>todo.id!==Number(_id)));        
        setToDos(todos.map(t=>{
            if(t.id===Number(_id)){
                return {...t, completed:true};
            }else{
                return t;
            }
        }))        
    }


    return (
        <>
        <h1>To-Do List</h1>
        <nav>
            <NavLink to="">To-Do 목록</NavLink> |
            <NavLink to="add">Add To-Do</NavLink>
        </nav>
        <Outlet context={{todos, addToDo, removeToDo }}></Outlet>
        </>

    );
}