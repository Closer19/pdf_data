import { useOutletContext } from "react-router-dom";

export default function AddToDo(){
    const {addToDo} = useOutletContext();
    const handleSubmit=(e)=>{
        e.preventDefault();
        addToDo(e.target.task.value);
    }

    return (
        <>
        <h2>Add New To-Do</h2>
        <form onSubmit={handleSubmit}>
            <label htmlFor="task"></label>
            <input type="text" name="task" id="task"></input>
            <button type="submit">Add-To-Do</button>
        </form>
        </>

    );
}