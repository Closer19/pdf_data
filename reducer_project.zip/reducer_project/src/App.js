import logo from './logo.svg';
import './App.css';
import LoginForm from './LoginFrom';
function App() {
  return (
    <LoginForm/>
  );
}

export default App;
