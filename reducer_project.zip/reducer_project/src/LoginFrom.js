import { useReducer } from "react";
const initialState = {
  userName: "",
  userPassword: "",
  isUserNameValid: false,
  isUserPasswordValid: false,
  isFormValid: false,
};

function reducer(state, action) {
  switch (action.type) {
    case "SET_USERNAME":
      const isNameValid = action.payload.length >= 5;
      return {
        ...state,
        userName: action.payload,
        isUserNameValid: isNameValid,
        isFormValid: isNameValid && state.isUserPasswordValid,
      };
    case "SET_PASSWORD":
      const isPasswordValid = action.payload.length >= 8;
      return {
        ...state,
        userPassword: action.payload,
        isUserPasswordValid: isPasswordValid,
        isFormValid: isPasswordValid && state.isUserNameValid,
      };
    case "RESET_FORM":
      return initialState;
    default:
      return state;
  }
}

export default function LoginForm() {
  const [state, dispatch] = useReducer(reducer, initialState);
  const handleSubmit = (e) => {
    e.preventDefault();
    alert("Form Submitted!");
    dispatch({ type: "RESET_FORM" });  
  };
  return (
    <>
      <form onSubmit={handleSubmit}>
        <label>
          UserName:
          <input
            name="userName"
            type="text"
            value={state.userName}
            onChange={(e) =>
              dispatch({ type: "SET_USERNAME", payload: e.target.value })
            }
          ></input>
        </label>
        {!state.isUserNameValid && state.userName && (
          <p style={{ color: "red" }}>
            Username must be at least 5 characters long.
          </p>
        )}
        <label>
          Password:
          <input
            name="password"
            type="password"
            value={state.userPassword}
            onChange={(e) => {
              dispatch({ type: "SET_PASSWORD", payload: e.target.value });
            }}
          ></input>
        </label>
        {!state.isUserPasswordValid && state.userPassword && (
          <p style={{ color: "red" }}>
            Passwrod must be at least 8 characters long.
          </p>
        )}
        <button type="submit" disabled={!state.isFormValid}>
          Submit
        </button>
      </form>
    </>
  );
}
