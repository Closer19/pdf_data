import { configureStore, createSlice } from '@reduxjs/toolkit';

// 초기 포스트 리스트
const initialPosts = [
  { id: 1, title: 'First Post', content: 'This is the first post' },
  { id: 2, title: 'Second Post', content: 'This is the second post' },
];

// Redux slice 생성
const postsSlice = createSlice({
  name: 'posts',
  initialState: initialPosts,
  reducers: {
    addPost: (state, action) => {
      state.push(action.payload);
    },
    updatePost: (state, action) => {
      const { id, title, content } = action.payload;
      const existingPost = state.find((post) => post.id === id);
      if (existingPost) {
        existingPost.title = title;
        existingPost.content = content;
      }
    },
    deletePost: (state, action) => {
      return state.filter((post) => post.id !== action.payload);
    },
  },
});

// Action과 reducer export
export const { addPost, updatePost, deletePost } = postsSlice.actions;
export default configureStore({
  reducer: {
    posts: postsSlice.reducer,
  },
});
