
import './App.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Provider } from 'react-redux';
import store from './store';
import Home from './pages/Home';
import PostList from './pages/PostList';
import PostDetail from './pages/PostDetail';
import PostWrite from './pages/PostWrite';
import PostEdit from './pages/PostEdit';
import About from './pages/About';


function App() {
  return (
    <BrowserRouter>
    <Routes>
          <Route path="/" element={<Home />}>
            <Route index element={<About />}/>
            <Route path="/posts" element={<PostList />} />
            <Route path="/posts/:id" element={<PostDetail />} />
            <Route path="/write" element={<PostWrite />} />
            <Route path="/edit/:id" element={<PostEdit />} />                      
          </Route>        
        </Routes>    
    </BrowserRouter>
    
  );
}

export default App;
