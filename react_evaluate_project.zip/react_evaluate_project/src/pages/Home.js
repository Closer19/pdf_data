import React from 'react';
import { Link, Outlet } from 'react-router-dom';
function Home() {
  return (
  <>  
  <h1>Home Page</h1>
        <nav>
          <Link to="/">Home</Link> | 
          <Link to="/posts">Post List</Link> | 
          <Link to="/write">Write Post</Link> |           
        </nav>
        <Outlet/>
  </>
  );
}

export default Home;
