import './App.css';
import { useDispatch, useSelector } from 'react-redux';
import { addTodo, removeTodo } from './todoSlice';
import { useState } from 'react';

function App() {
  const [text, setText]=useState("");
  const todos=useSelector(state=>state.todos.items);
  const dispatch=useDispatch();

  const handleAddTodo=(e)=>{
    if (text.trim()) {
      dispatch(addTodo(text));
      setText(""); // 입력 필드 초기화
    }
  }

  return (
    <div>
      <h1>To-Do List</h1>
      <input
        type="text"
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Add a new task"
      />
      <button onClick={handleAddTodo}>Add Todo</button>
      <ul>
        {todos.map((todo) => (
          <li key={todo.id}>
            {todo.text}
            <button onClick={() => dispatch(removeTodo(todo.id))}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
        
  );
}

export default App;
