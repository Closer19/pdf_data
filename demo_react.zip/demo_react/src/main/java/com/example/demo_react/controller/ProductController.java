package com.example.demo_react.controller;

import com.example.demo_react.data.Product;
import com.example.demo_react.data.ProductDTO;
import com.example.demo_react.data.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@RequiredArgsConstructor
public class ProductController {
    private final ProductRepository productRepository;

    @GetMapping(value="/product-list")
    public ResponseEntity<List<ProductDTO>> getProductList() {
        List<Product> productList = this.productRepository.findAll();
        List<ProductDTO> productDTOList= new ArrayList<>();
        for(Product product:productList){
            ProductDTO productDTO = ProductDTO.builder()
                    .id(product.getId())
                    .price(product.getPrice())
                    .title(product.getTitle())
                    .imgsrc(product.getImgsrc())
                    .build();

            productDTOList.add(productDTO);
        }
        return ResponseEntity.status(HttpStatus.OK).body(productDTOList);
    }

    @PostMapping(value="/product")
    public ResponseEntity<ProductDTO> addProduct(@RequestBody ProductDTO product) {
        Product newProduct = Product.builder()
                .title(product.getTitle())
                .price(product.getPrice())
                .imgsrc("http://via.placeholder.com/150x150/00ff00")
                .created(LocalDateTime.now())
                .description("생성")
                .build();
        this.productRepository.save(newProduct);

        ProductDTO productDTO=ProductDTO.builder()
                .id(newProduct.getId())
                .title(newProduct.getTitle())
                .price(newProduct.getPrice())
                .imgsrc(newProduct.getImgsrc())
                .build();

        return ResponseEntity.status(HttpStatus.OK).body(productDTO);
    }

    @PutMapping(value="/product")
    public ResponseEntity<ProductDTO> updateProduct(@RequestBody ProductDTO product) {
        Optional<Product> productOptional=this.productRepository.findById(product.getId());
        Product updatedProduct=null;
        if(productOptional.isPresent()) {
            updatedProduct = productOptional.get();
            updatedProduct.setTitle(product.getTitle());
            updatedProduct.setPrice(product.getPrice());
            updatedProduct.setCreated(LocalDateTime.now());
            updatedProduct.setDescription("수정됨");
            this.productRepository.save(updatedProduct);
            ProductDTO productDTO=ProductDTO.builder()
                    .id(updatedProduct.getId())
                    .title(updatedProduct.getTitle())
                    .price(updatedProduct.getPrice())
                    .imgsrc(updatedProduct.getImgsrc())
                    .build();
            return ResponseEntity.status(HttpStatus.OK).body(productDTO);
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
    }

    @DeleteMapping(value="/product/{id}")
    public ResponseEntity<String> deleteProduct(@PathVariable("id") Integer id) {
        Optional<Product> productOptional=this.productRepository.findById(id);
        if(productOptional.isPresent()) {
            this.productRepository.deleteById(id);
            return ResponseEntity.status(HttpStatus.OK).body(String.valueOf(id));
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("없는 아이디");
    }

}
