package com.example.demo_react.controller;

import com.example.demo_react.data.Product;
import com.example.demo_react.data.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class ProductController {
    private final ProductRepository productRepository;

    @GetMapping(value="/product-list")
    public List<Product> getProductList() {
        List<Product> productList = this.productRepository.findAll();
        return productList;
    }


}
