import {useDispatch, useSelector} from "react-redux";
import {Link} from "react-router-dom";
import {productDelete} from "./productSlice";

export default function List(){
    const pdList=useSelector(state=>state.product.pdList);
    const dispatch=useDispatch();
    const handleDelete=async (e)=>{
        try{
            const response=await fetch("http://localhost:8080/product/"+e.target.id,{
                method:"DELETE",
            });
            if(!response.ok){
                throw new Error("상품정보 삭제시 오류가 발생했습니다.");
            }
            const result=await response.json();

            if(Number(result)== -1){
                throw new Error("없는 아이디의 상품입니다.");
            }
            dispatch(productDelete(Number(result)));
        }catch(error){
            console.log(error);
        }
    }
    const list=pdList.map(t=>(
        <div key={t.id}>
            <Link to={"/detail-product/"+t.id}><img src={t.imgsrc}/></Link>
            <h2>{t.title}</h2>
            <Link to={"/edit-product/"+t.id}>🖋️</Link>️
            <span id={t.id} onClick={handleDelete}>🗑️</span>
        </div>
    ));

    return (
        <>
            <div>
                {list}
            </div>

        </>
    );
}

