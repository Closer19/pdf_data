import {Outlet} from "react-router-dom";
import Navigate from "./Navigate";
import {useSelector, useDispatch} from "react-redux";
import {useEffect} from "react";
import {productAdd} from "./productSlice";

export default function MainLayout(){
    const dispatch=useDispatch();
    const pdList=useSelector(state=>state.product.pdList);

    useEffect(()=>{
        fetch("http://localhost:8080/product-list")
            .then(response=>{
                if(!response.ok){
                    throw new Error("초기 상품정보를 가져오는데 오류가 발생했습니다.");
                }
                return response.json();
            })
            .then(data=>{
                data.map(t=>dispatch(productAdd(t)));
            })
            .catch(error=>console.log(error));

    }, []);



    return (<>
        <h1>TEST STORE</h1>
        <Navigate></Navigate>
        <Outlet></Outlet>

    </>);
}


