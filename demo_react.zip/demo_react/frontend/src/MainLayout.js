import {Outlet} from "react-router-dom";
import Navigate from "./Navigate";
import {useSelector, useDispatch} from "react-redux";
import {useEffect} from "react";
import {productAdd} from "./productSlice";

export default function MainLayout(){
    const dispatch=useDispatch();
    const pdList=useSelector(state=>state.product.pdList);

    useEffect(()=>{
       const fetchData=async ()=>{
           try{
               const response= await fetch("http://localhost:8080/product-list");
               if(!response.ok){
                   throw new Error("초기데이터 수신 오류");
               }
               const result=await response.json();
               result.map(t=>dispatch(productAdd(t)));
           }catch(error){
               console.log(error);
           }
       };
       fetchData();
       }, []);

    return (<>
        <h1>TEST STORE</h1>
        <Navigate></Navigate>
        <Outlet></Outlet>

    </>);
}


