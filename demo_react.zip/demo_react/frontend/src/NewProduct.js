import {useDispatch} from "react-redux";
import {useRef} from "react";
import {productAdd} from "./productSlice";
import {useNavigate} from "react-router-dom";

export default function NewProduct(){
    const dispatch=useDispatch();
    const navigate=useNavigate();

    const handleSubmit=async (e)=>{
        try{
            e.preventDefault();
            const response=await fetch("http://localhost:8080/product",{
                method:"POST",
                headers:{
                    "Content-Type" : "application/json",
                },
                body:JSON.stringify({title:e.target.title.value, price:e.target.price.value})
            });
            if(!response.ok){
                throw new Error("새상품 등록시 오류가 발생했습니다.");
            }
            const result=await response.json();
            dispatch(productAdd(result));

        }catch(error){
            console.log(error);
        }
        navigate("/");
    }

    return(
        <>
            <h2>New Product</h2>
            <form onSubmit={handleSubmit}>
                <input type="text" name="title"></input>
                <input type="text" name="price"></input>
                <button type="submit">저장</button>
            </form>
        </>
    );
}