package com.example.demo;

import com.example.demo.data.Product;
import com.example.demo.data.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.Optional;

@RequiredArgsConstructor
@Controller
public class ProductController {

    private final ProductRepository productRepository;

//    @Autowired
//    public ProductController(ProductRepository productRepository) {
//        this.productRepository = productRepository;
//    }

    @GetMapping(value = "/list")
    public String list(Model model) {
        List<Product> productList = this.productRepository.findAll();
        model.addAttribute("productList", productList);
        return "list.html";
    }

    @GetMapping(value = "/detail/{id}")
    public String detail(@PathVariable("id") Integer id, Model model) {
        Optional<Product> result = this.productRepository.findById(id);
        if (result.isPresent()) {
            model.addAttribute("product", result.get());
            return "detail.html";
        }
        return "redirect:/list";
    }

    @GetMapping(value = "/new-product")
    public String newProduct(Model model) {
        return "new-product.html";
    }

    @PostMapping(value = "/new-product")
    public String newProduct(@RequestParam String title,
                             @RequestParam Integer price) {
        Product product = new Product();
        product.setPrice(price);
        product.setTitle(title);
        product.setImgsrc("http://via.placeholder.com/150x150/ffff00");
        this.productRepository.save(product);
        return "redirect:/list";
    }

    @PostMapping(value = "/update-product/{id}")
    public String updateProduct(@PathVariable("id") Integer id,
                                @RequestParam String title,
                                @RequestParam Integer price) {
        Optional<Product> result = this.productRepository.findById(id);
        if (result.isPresent()) {
            Product product = result.get();
            product.setTitle(title);
            product.setPrice(price);
            this.productRepository.save(product);
        }
        return "redirect:/list";
    }


    @GetMapping(value = "/update-product/{id}")
    public String updateProduct(@PathVariable("id") Integer id, Model model) {
        Optional<Product> result = this.productRepository.findById(id);
        if (result.isPresent()) {
            model.addAttribute("product", result.get());
            return "update-product.html";
        }
        return "redirect:/list";
    }

    @GetMapping(value="/delete-product/{id}")
    public String deleteProduct(@PathVariable("id") Integer id) {
        this.productRepository.deleteById(id);
        return "redirect:/list";
    }


}
