package com.example.demo.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
@RequiredArgsConstructor
public class PostController {
    private final PostRepository postRepository;

    @GetMapping(value="/post")
    public String list(Model model){
        List<Post> result=this.postRepository.findAll();
        model.addAttribute("result", result);
        System.out.println();
        return "postlist.html";
    }
}
