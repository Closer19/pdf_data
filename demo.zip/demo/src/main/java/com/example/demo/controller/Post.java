package com.example.demo.controller;

import jakarta.persistence.*;

import java.util.Date;

@Entity
@Table (name="post")
public class Post {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    public Long id;
    public String title;
    public Date created;
}
