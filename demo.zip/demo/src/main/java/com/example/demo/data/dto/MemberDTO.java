package com.example.demo.data.dto;

public class MemberDTO {
    public String name="김진아";
    public String email="prettkja@gmail.com";
    public String organization="하이미디어아카데미";

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getOrganization() {
        return organization;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setOrganization(String organization) {
        this.organization = organization;
    }

    @Override
    public String toString() {
        return  "name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", organization='" + organization + '\'' ;
    }
}