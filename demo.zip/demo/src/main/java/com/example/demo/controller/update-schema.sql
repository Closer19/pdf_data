CREATE TABLE item
(
    id    BIGINT AUTO_INCREMENT NOT NULL,
    title VARCHAR(255) NULL,
    price INT NULL,
    CONSTRAINT pk_item PRIMARY KEY (id)
);