package com.example.demo;

import com.example.demo.data.MemerDTO;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
//@Controller
public class HelloController {

//    @ResponseBody
    @GetMapping(value="/hello")
    public String sayHello() {
        return "hello.html";
    }

    @GetMapping(value="/var/{var}")
    public String sayHello(@PathVariable("var") String v) {
        return v;
    }
//    http://localhost:8080/var?name=김진아&age=25
    @GetMapping(value="/var")
    public String sayHello2(@RequestParam String name,
                            @RequestParam String age) {
        return "name:"+name+",  age:"+age;
    }
//http://localhost:8080/var2?name=김진아&age=25&email=kja0204@gmail.com
    @GetMapping(value="/var2")
    public String sayHello3(@RequestParam Map<String,String> map) {
        return "name2:"+map.get("name")+",  age2:"+map.get("age");
    }
    //http://localhost:8080/var3?name=김진아&age=25&email=kja0204@gmail.com
    @GetMapping(value="/var3")
    public String sayHello4(MemerDTO member) {
        return member.toString();
    }




}
