import logo from './logo.svg';
import './App.css';
import {BrowserRouter, Routes, Route} from "react-router-dom";
import MainLayout from "./pages/MainLayout";
import Home from "./pages/Home";
import DetailCondition from "./pages/DetailCondition";
import ConditionSelect from "./pages/ConditionSelect";
import DisplayUserInfo from "./pages/DisplayUserInfo";
import DisplayBuyInfo from "./pages/DisplayBuyInfo";
import CreateUserInfo from "./pages/CreateUserInfo";
import JoinUser from "./pages/JoinUser";
import AddBuyInfo from "./pages/AddBuyInfo";
import Login from "./pages/Login";

function App() {
  return (
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<MainLayout/>}>
            <Route index element={<Home/>}/>
            <Route path="/search" element={<ConditionSelect/>}>
              <Route path="/search/detail-condition" element={<DetailCondition/>}/>
            </Route>
            <Route path="/display-userinfo" element={<DisplayUserInfo/>}></Route>
            <Route path="/display-buyinfo/:userid" element={<DisplayBuyInfo/>}></Route>
            <Route path="/create-userinfo" element={<CreateUserInfo/>}>
                <Route path="/create-userinfo/join" element={<JoinUser/>}></Route>
                <Route path="/create-userinfo/add-buyinfo" element={<AddBuyInfo/>}></Route>
            </Route>
          <Route path="/customer-login" element={<Login/>}></Route>
          </Route>
        </Routes>
      </BrowserRouter>

  );
}

export default App;
