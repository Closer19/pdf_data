import {createSlice, configureStore} from "@reduxjs/toolkit";

const userInfoSlice=createSlice({
    name:"userInfo",
    initialState:{
        userInfoList:[],
        count:0,
        loginFlag:false,
    },
    reducers: {
        addUserInfo: (state, action) => {
            state.userInfoList.push(action.payload);
            state.count++;
        },
        clearUserInfo: (state) => {
            state.userInfoList = [];
            state.count = 0;
        },
        login: (state) => {
            state.loginFlag = true;
        },
        logout: (state) => {
            state.loginFlag = false;
        },
    }
});

const store=configureStore({
    reducer:{
        userInfo:userInfoSlice.reducer,
    }
});

export const {addUserInfo,clearUserInfo, login,logout }=userInfoSlice.actions;
export default store;