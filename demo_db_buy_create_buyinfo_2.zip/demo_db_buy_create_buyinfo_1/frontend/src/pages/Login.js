import React, {useState, useRef} from "react";
import axios from "axios";
import apiClient from "../api/axiosInstance";
import {login} from "../store";
import {useDispatch, useSelector} from "react-redux";

function Login() {
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const dispath=useDispatch();
    const login_flag=useSelector(state=>state.userInfo.loginFlag);
    // const usernameRef=useRef();
    // const passwordRef=useRef();

    const handleLogin = async (e) => {
        e.preventDefault();
        try {
            const response = await apiClient.post(
                "/login",
                new URLSearchParams({ username, password })
                // x-www-form-urlencoded 방식
            );
            console.log(response.data);
            alert(response.data.result);
            dispath(login());
        } catch (error) {
            console.log(error);
            console.log(error.response.data);
            alert("계정정보가 일치하지 않습니다.");
            e.target.username.value="";
            e.target.password.value="";
        }
    };

    return (
        <div>
            {!login_flag && <form onSubmit={handleLogin}>
                <p><input
                    type="text"
                    placeholder="Username"
                    name="username"
                    value={username}
                    // ref={usernameRef}
                    onChange={(e) => setUsername(e.target.value)}
                /></p>
                <p><input
                    type="password"
                    placeholder="Password"
                    name="password"
                    value={password}
                    // ref={passwordRef}
                    onChange={(e) => setPassword(e.target.value)}
                />
                </p>
                <button type="submit">Login</button>
            </form>}
        </div>
    );
}

export default Login;
