package com.example.demo_db.service;


import com.example.demo_db.data.repository.UserEntityRepository;
import com.example.demo_db.data.entity.UserEntity;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class UserLoginService implements UserDetailsService {
    private final UserEntityRepository userEndtityRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Optional<UserEntity> userEntity =this.userEndtityRepository.findById(username);
        if(userEntity.isEmpty()){
            throw new UsernameNotFoundException("User not found");
        }

        UserEntity user = userEntity.get();
        List<GrantedAuthority> grantedAuthorities = new ArrayList<>();
        if(user.getUserName().equals("bbb")){
            grantedAuthorities.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
        } else {
            grantedAuthorities.add(new SimpleGrantedAuthority("ROLE_NORMAL"));}
        return new User(user.getUserName(), user.getPassword(), grantedAuthorities);
    }

}

