package com.example.awstest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AwstestApplicationTests {

    @Test
    void contextLoads() {
    }

}
