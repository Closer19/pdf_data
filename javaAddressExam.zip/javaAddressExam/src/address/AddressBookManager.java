package address;

import java.util.Scanner;

public class AddressBookManager {
    private AddressBook addressBook;
    private Scanner scanner;

    public AddressBookManager() {
        this.addressBook = new AddressBook();
        this.scanner = new Scanner(System.in);
    }

    public void run() {
        while (true) {
            System.out.println("\n=== 주소록 프로그램 ===");
            System.out.println("1. 연락처 추가");
            System.out.println("2. 연락처 조회");
            System.out.println("3. 연락처 삭제");
            System.out.println("4. 전체 연락처 보기");
            System.out.println("5. 종료");
            System.out.print("선택하세요: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // 개행 문자 제거

            try {
                switch (choice) {
                    case 1:
                        this.addContact();
                        break;
                    case 2:
                        this.findContact();
                        break;
                    case 3:
                        this.removeContact();
                        break;
                    case 4:
                        addressBook.displayContacts();
                        break;
                    case 5:
                        System.out.println("프로그램을 종료합니다.");
                        return;
                    default:
                        System.out.println("잘못된 선택입니다. 다시 시도하세요.");
                        break;
                }
            } catch (DuplicateContactException | ContactNotFoundException e) {
                System.out.println("에러: " + e.getMessage());
            }
        }
    }

    private void addContact() throws DuplicateContactException {
        System.out.print("이름을 입력하세요: ");
        String name = scanner.nextLine();
        System.out.print("전화번호를 입력하세요: ");
        String phone = scanner.nextLine();
        if(addressBook.addContact(name, phone)) {
            System.out.println("연락처가 추가되었습니다.");
        }else{
            System.out.println("주소록이 가득 찼습니다. 더 이상 추가할 수 없습니다.");
        }

    }

    private void findContact() throws ContactNotFoundException {
        System.out.print("조회할 이름을 입력하세요: ");
        String name = scanner.nextLine();
        Contact contact = addressBook.findContact(name);
        System.out.println("조회 결과: " + contact);
    }

    private void removeContact() throws ContactNotFoundException {
        System.out.print("삭제할 이름을 입력하세요: ");
        String name = scanner.nextLine();
        if(addressBook.removeContact(name)){
            System.out.println("연락처가 삭제되었습니다.");
        }
    }
}
