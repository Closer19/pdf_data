package address;

public class Main {
    public static void main(String args[]) {
        AddressBookManager manager = new AddressBookManager();
        manager.run();
    }
}