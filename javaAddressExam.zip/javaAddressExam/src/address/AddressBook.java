package address;

public class AddressBook {
    private Contact[] contacts;
    private int contactCount;

    public AddressBook() {
        // 최대 연락처 수 설정: 참조만 저장할 배열 생성 (크기 10)
        this.contacts = new Contact[10];
        this.contactCount = 0;
    }

    public boolean addContact(String name, String phone) throws DuplicateContactException {
        for (int i = 0; i < contactCount; i++) {
            if (contacts[i].getName().equals(name)) {
                throw new DuplicateContactException("이미 존재하는 연락처입니다: " + name);
            }
        }

        if (contactCount < contacts.length) {
            // 새로운 Contact 객체를 생성하여 배열에 할당
            contacts[contactCount] = new Contact(name, phone);
            contactCount++;
            return true;
        }else {
            return false;
        }
    }

    public Contact findContact(String name) throws ContactNotFoundException {
        for (int i = 0; i < contactCount; i++) {
            if (contacts[i].getName().equals(name)) {
                return contacts[i];
            }
        }
        throw new ContactNotFoundException("연락처를 찾을 수 없습니다: " + name);
    }

    public boolean removeContact(String name) throws ContactNotFoundException {
        int removeIndex = -1;
        for (int i = 0; i < contactCount; i++) {
            if (contacts[i].getName().equals(name)) {
                removeIndex = i;
                break;
            }
        }
        if (removeIndex == -1) {
            throw new ContactNotFoundException("연락처를 찾을 수 없습니다: " + name);
        }

        // 연락처 삭제 후, 배열을 한 칸씩 당깁니다.
        for (int i = removeIndex; i < contactCount - 1; i++) {
            contacts[i] = contacts[i + 1];
        }
        contacts[contactCount - 1] = null;
        contactCount--;
        return true;
    }

    public void displayContacts() {
        if (contactCount == 0) {
            System.out.println("저장된 연락처가 없습니다.");
        } else {
            for (int i = 0; i < contactCount; i++) {
                System.out.println(contacts[i]);
            }
        }
    }
}
