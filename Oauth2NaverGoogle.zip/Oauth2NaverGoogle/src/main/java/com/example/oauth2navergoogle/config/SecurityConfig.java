package com.example.oauth2navergoogle.config;

import com.example.oauth2navergoogle.jwt.JwtFilter;
import com.example.oauth2navergoogle.jwt.JwtUtil;
import com.example.oauth2navergoogle.oauth2.CustomSucessHandler;
import com.example.oauth2navergoogle.service.CustomOauth2UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;

@Configuration
@EnableWebSecurity
@RequiredArgsConstructor
public class SecurityConfig {
    private final CustomOauth2UserService customOauth2UserService;
    private final CustomSucessHandler customSucessHandler;
    private final JwtUtil jwtUtil;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http.csrf(csrf->csrf.disable())
                .formLogin(formLogin->formLogin.disable())
                .httpBasic(httpBasic->httpBasic.disable())

                .authorizeHttpRequests(auth->
                        auth.requestMatchers("/").permitAll()
                                .anyRequest().authenticated());

        http.cors(cors->cors.configurationSource(request -> {
            CorsConfiguration config = new CorsConfiguration();
            config.setAllowCredentials(true);
            config.addAllowedOrigin("http://localhost:3000");
            config.addAllowedHeader("*");
            config.addAllowedMethod("*");
            return config;
        }));

        http.sessionManagement(session->
                session.sessionCreationPolicy(SessionCreationPolicy.STATELESS));

        http.oauth2Login(oauth2->oauth2.userInfoEndpoint((userInfoConfig->
                userInfoConfig.userService(this.customOauth2UserService)))
                .successHandler(this.customSucessHandler));

        http.addFilterBefore(new JwtFilter(this.jwtUtil), UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }
}
