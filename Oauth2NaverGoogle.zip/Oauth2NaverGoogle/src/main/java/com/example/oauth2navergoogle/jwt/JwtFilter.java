package com.example.oauth2navergoogle.jwt;

import com.example.oauth2navergoogle.dto.CustomOAuth2User;
import com.example.oauth2navergoogle.dto.UserDTO;
import io.jsonwebtoken.ExpiredJwtException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
@RequiredArgsConstructor
public class JwtFilter extends OncePerRequestFilter {
    private final JwtUtil jwtUtil;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        String token=null;
        Cookie[] cookies = request.getCookies();
        for(Cookie cookie:cookies){
            if(cookie.getName().equals("Authorization")){
                token = cookie.getValue();
            }
        }
        if(token==null){
            filterChain.doFilter(request, response);
            return;
        }

        try{
            this.jwtUtil.isExpired(token);
        }catch(ExpiredJwtException e){
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write("만료된 토큰");
            return;
        }

        String username=this.jwtUtil.getUsername(token);
        String role=this.jwtUtil.getRole(token);

        UserDTO userDTO=new UserDTO();
        userDTO.setUsername(username);
        userDTO.setRole(role);

        CustomOAuth2User customOAuth2User=new CustomOAuth2User(userDTO);

        Authentication authentication=new UsernamePasswordAuthenticationToken(customOAuth2User,null,customOAuth2User.getAuthorities());

        SecurityContextHolder.getContext().setAuthentication(authentication);
        filterChain.doFilter(request, response);
    }
}
