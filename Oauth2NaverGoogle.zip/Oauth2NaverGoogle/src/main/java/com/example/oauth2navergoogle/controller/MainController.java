package com.example.oauth2navergoogle.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MainController {

    @GetMapping(value="/req")
    public String req() {
        return "Hello World";
    }
}
