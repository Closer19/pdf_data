import { useDispatch, useSelector } from "react-redux";
import { addItem, removeItem, updateItem } from "./cartSlice";

function App() {
  const dispatch = useDispatch();
  const cartItems = useSelector((state) => state.cart.items);
  const products = [
    { id: 1, name: "Product A", price: 100 },
    { id: 2, name: "Product B", price: 200 },
    { id: 3, name: "Product C", price: 300 },
  ];

  return (
    <>
      <h1>Products</h1>
      <ul>
        {products.map((p) => (
          <li key={p.id}>
            {p.name} - {p.price}원
            <button
              onClick={() => {
                dispatch(addItem(p));
              }}
            >
              Add to Cart
            </button>
          </li>
        ))}
      </ul>
      <h1>Shopping Cart</h1>
      <ul>
        {cartItems.map((t) => (
          <li key={t.id}>
            {t.name} - {t.price}원 X {t.quantity}&nbsp;&nbsp;
            <button onClick={() => dispatch(removeItem(t.id))}>Remove</button>
            <input
              type="number"
              value={t.quantity}
              onChange={(e) =>
                dispatch(updateItem({ id: t.id, quantity: Number(e.target.value) }))
              }
            ></input>
          </li>
        ))}
      </ul>
      <h2>Total</h2>
      {cartItems.reduce((acc, t)=>acc+(t.price*t.quantity),0)}원
    </>
  );
}

export default App;
