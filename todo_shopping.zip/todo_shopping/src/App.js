import "./App.css";
import { useDispatch, useSelector } from "react-redux";
import { addToDo, removeToDo } from "./todoSlice";
import { useState } from "react";

function App() {
  const todos = useSelector((state) => state.todos.items);
  const dispatch = useDispatch();
  const [text, setText] = useState("");
  const handleAddTodo=(e)=>{
    if(text.trim()){
      dispatch(addToDo(text));
      setText("");
    }
  }
  return (
    <>
      <h1>To-Do List</h1>
      <input
        type="text"
        value={text}
        onChange={(e) => {
          setText(e.target.value);
        }}
        placeholder="Add a new task"
      ></input>
      <button onClick={handleAddTodo}>Add Todo</button>
      <ul>
        {todos.map(todo=>(
          <li key={todo.id}>
            {todo.task}
            <button onClick={()=>dispatch(removeToDo(todo.id))}>Delete</button>
          </li>
        ))}
      </ul>
    </>
  );
}
export default App;
