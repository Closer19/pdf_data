import { createSlice } from "@reduxjs/toolkit";

const cartSlice=createSlice({
    name:"cart",
    initialState:{
        items:[],//{id:.., name:..., price:...., quantity:...}
    },
    reducers:{
        addItem:(state, action)=>{
            const index=state.items.findIndex(t=>t.id===action.payload.id);
            if(index>=0){
                state.items[index].quantity+=1;
            }else{
                state.items.push({...action.payload, quantity:1});
            }
        },
        removeItem:(state, action)=>{
            state.items=state.items.filter(t=>t.id!==action.payload);

        },
        updateItem:(state, action)=>{
            const {id, quantity}=action.payload;
            state.items=state.items.map(t=>t.id===id?{...t, quantity:quantity}:t);     
        },
    }
});

export const {addItem,removeItem, updateItem}=cartSlice.actions;
export default cartSlice.reducer;